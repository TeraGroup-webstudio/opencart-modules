<?php
// Heading
$_['text_not_call_me']						= 'Don\'t call me, I\'m sure of the order';
$_['text_contact_telegram_viber'] 		= 'Contact via Telegram/Viber';
$_['text_model']								= 'Product Code: ';
$_['text_i_am_registered']					= 'I am registered';
$_['text_op_customer']						= 'Customer';
$_['title_shipping_method']   			= 'Shipping method';
$_['title_payment_method']   				= 'Payment method';
$_['title_shipping_address']   			= 'Delivery Details';
$_['text_min_totals_order']            = 'Minimum order amount - %s';
$_['title_country_region'] 				= 'Country and Region';
$_['text_free_shipping_left'] 			= '<div class="text-free-shipping">Free shipping left</div> <span class="sum-free-shipping-left">%s</span>' ;
$_['text_free_shipping'] 					= 'Free shipping';
$_['text_you_order'] 						= 'Your order';
$_['text_reward'] 							= '<span>Use reward points</span> <span class="reward-body"><span class="reward-available">Available:</span> <span class="reward-amount">%s</span></span>';
$_['text_coupon'] 							= 'Promocode';
$_['text_gift'] 							  = 'Your gift for the order 🔥';
$_['text_voucher'] 							= 'Certificate';
$_['entry_coupon']							= 'Enter your promocode here';
$_['entry_voucher']							= 'Enter your certificate code here';
$_['column_price']							= 'For 1 piece:';

$_['text_login']                   		= 'Login';
$_['text_register']                		= 'Register Account';
$_['text_forgotten']               		= 'Forgotten Password ?';
$_['entry_email']								= 'Email Address';
$_['entry_password']							= 'Password';

// Error
$_['error_login']								= 'Warning: No match for Email Address and/or Password.';
$_['error_attempts']							= 'Warning: Your account has exceeded allowed number of login attempts. Please try again in 1 hour.';
$_['error_approved']							= 'Warning: Your account requires approval before you can login.';
$_['error_register']							= 'The order is available only to registered customers.';
$_['error_format_telephone']				= 'Incorrect phone number format!';