// Видаляє всі файли .DS_Store (сміття від macOS Finder) у папці проєкту.
// Використання:
//   npm run clean:ds            — видалити
//   npm run clean:ds -- --dry   — тільки показати, що буде видалено
import { readdir, unlink } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SKIP_DIRS = new Set(['.git']);
const DRY_RUN = process.argv.includes('--dry') || process.argv.includes('--dry-run');

async function walk(dir, found) {
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch (err) {
    console.warn(`⚠️  Не вдалося прочитати ${dir}: ${err.message}`);
    return;
  }

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (!SKIP_DIRS.has(entry.name)) await walk(fullPath, found);
    } else if (entry.name === '.DS_Store') {
      found.push(fullPath);
    }
  }
}

const found = [];
await walk(ROOT, found);

if (found.length === 0) {
  console.log('✅ Файлів .DS_Store не знайдено');
  process.exit(0);
}

let removed = 0;
for (const file of found) {
  const rel = path.relative(ROOT, file);
  if (DRY_RUN) {
    console.log(`🔍 ${rel}`);
    continue;
  }
  try {
    await unlink(file);
    removed++;
    console.log(`🗑️  ${rel}`);
  } catch (err) {
    console.warn(`⚠️  Не вдалося видалити ${rel}: ${err.message}`);
  }
}

console.log(
  DRY_RUN
    ? `\nЗнайдено ${found.length} файл(ів) .DS_Store (dry run, нічого не видалено)`
    : `\nВидалено ${removed} з ${found.length} файл(ів) .DS_Store`
);
