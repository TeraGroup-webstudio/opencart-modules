# OpenCart FTP Live Sync (Node)

> **⚠️ ВАЖЛИВО:** У файлі `package.json` у полі `"name"` замініть `project` на назву вашого проєкту.
> Наприклад, якщо проєкт називається `myshop`, змініть:
>
> ```json
> "name": "myshop-opencart-sync"
> ```
>
> Формат: `{назва-проєкту}-opencart-sync`

## 🚀 Швидкий старт

Скрипт підтримує два протоколи підключення до хостингу — обирається параметром `FTP_PROTOCOL`:

| `FTP_PROTOCOL` | Коли використовувати | Порт за замовчуванням | Авторизація |
|---|---|---|---|
| `ftp` (за замовчуванням) | Хостинг дає лише звичайний FTP/FTPS-доступ (типово для shared-хостингів) | 21 | лише `FTP_PASSWORD`, за потреби `FTP_SECURE=true` для FTPS |
| `sftp` | Хостинг дає доступ по SSH/SFTP (типово для Hetzner та подібних VPS) | 22 (у Hetzner часто 2222) | `FTP_PASSWORD` або `FTP_PRIVATE_KEY_PATH` |

У файлі `.env.ftp.shared` вкажіть актуальні дані проєкту:

- `LIVE_RELOAD_URL`
- `FTP_PROTOCOL` (`sftp` або `ftp`)
- `FTP_HOST` — без схеми, тобто без `sftp://`/`ftp://` на початку
- `FTP_PORT`
- `FTP_USER`
- `FTP_REMOTE_BASE`

Повний перелік і пояснення всіх параметрів — у `.env.ftp.example`.

Посилання на макет Figma задайте у `.env.ftp.shared`:

```dotenv
FIGMA_URL="https://www.figma.com/design/your-file"
```

Рядок «Макет Figma: посилання» на початку README оновлюється з `FIGMA_URL` під час `npm run pull:remote` або `npm run dev`. Після зміни посилання можна оновити лише README командою `npm run sync:readme`. Якщо `FIGMA_URL` порожній або відсутній, рядок «Макет Figma» не виводиться.

Потім запустіть:

```bash
npm install
npm run pull:remote
npm run dev
```

При першому запуску консоль попросить ввести FTP-пароль — він збережеться локально у файлі `.env.ftp`.

---

**Якщо підключаєтесь до FTP перенесеного сайту** — у файлі `.env.ftp` вкажіть:

- `LIVE_RELOAD_URL`
- `FTP_HOST`
- `FTP_USER`
- `FTP_PASSWORD`
- `FTP_REMOTE_BASE`

І потім запустіть:

```bash
npm run dev
```

## 🔄 Звичний Git-процес роботи (merge)

Щоб оновити свою робочу гілку актуальними змінами з `main`, використовуйте стандартний процес через `merge`:

```bash
git checkout main
git pull origin main
git checkout your-branch-name
git merge main
git push origin your-branch-name
```

Якщо під час злиття виникнуть конфлікти:
1. Виправте конфлікти у відповідних файлах
2. Збережіть зміни
3. Виконайте команди:

```bash
git add .
git commit
git push origin your-branch-name
```

---

Для переходу у вашу робочу гілку:

```bash
git checkout your-branch-name
```

### Що робить `git fetch`

`git fetch` завантажує нові коміти та гілки з віддаленого репозиторію, але не змінює ваші локальні файли і не зливає зміни автоматично.

Типовий варіант з `fetch`:

```bash
git fetch origin
git checkout your-branch-name
git merge origin/main
```

Це зручно, коли ви хочете спочатку отримати оновлення, перевірити їх, а вже потім свідомо зробити `merge`.

Локальний процес розробки OpenCart з:
- автоматичним завантаженням змін на хостинг через FTP;
- live reload у браузері після збереження файлу;
- опційним pull контенту з хостингу (наприклад, з адмінки);
- автодеплоєм з GitHub Actions на хостинг.

## Основна ідея

- `.env.ftp.shared` зберігається в Git і містить спільні налаштування проєкту (хост, користувач, шлях, правила синку).
- `.env.ftp` є локальним файлом розробника (ігнорується Git).
- При першому `npm run dev` файл `.env.ftp` створюється автоматично з `.env.ftp.shared`.
- `FTP_PASSWORD` береться в такому пріоритеті:
1. `FTP_PASSWORD` (глобальна змінна середовища)
2. `FTP_PASSWORD_GLOBAL`
3. `DEV_FTP_PASSWORD`
4. запит у терміналі при першому запуску

Тому не потрібно пересилати `.env.ftp` між розробниками.

## Якщо у всіх проєктах один FTP пароль

Задайте один глобальний пароль на машині кожного розробника:
```powershell
setx FTP_PASSWORD "YOUR_PASSWORD"
```

Для кожного нового проєкту достатньо закомітити `.env.ftp.shared` і змінити:
- `FTP_REMOTE_BASE` (обов'язково)
- `LIVE_RELOAD_URL` (зазвичай інший для кожного проєкту)

Інші значення можна лишити спільними, якщо FTP хост і користувач однакові.

## Швидкий старт для розробника

1. Встановіть залежності:
```bash
npm install
npm run pull:remote
```

2. Рекомендовано один раз задати глобальний FTP пароль:
```powershell
setx FTP_PASSWORD "YOUR_PASSWORD"
```
Після `setx` закрийте і відкрийте термінал заново.

3. Запустіть dev-синк:
```bash
npm run dev
```

При першому запуску:
- `.env.ftp` створиться автоматично;
- якщо глобального пароля нема, скрипт один раз попросить `FTP_PASSWORD` і збереже його в локальний `.env.ftp`.

## Режими синку контенту

### `CONTENT_SYNC_MODE=bidirectional`
- локальні зміни завантажуються на хостинг;
- із хостингу робиться pull у локальний проєкт для `REMOTE_PULL_PATHS` (типово: `admin,catalog,system,image`).

Рекомендовано, якщо контент додається через адмінку OpenCart.

### `CONTENT_SYNC_MODE=push-only`
- тільки локально -> хостинг;
- автоматичного pull з хостингу немає.

Використовуйте, якщо контент має лишатися тільки на хостингу.

## Політика для image/cache

`image/cache/**` за замовчуванням виключений і з upload, і з pull.
Локальний кеш залишається чистим і не потрапляє в Git.

## Поведінка при видаленні файлів

- Якщо локально видалити файл у відстежуваних шляхах, на хостингу він теж видаляється.
- Видалення з хостингу у локальний проєкт застосовується тільки якщо увімкнено `REMOTE_PULL_DELETE`.
- `REMOTE_PULL_DELETE` впливає тільки на шляхи з `REMOTE_PULL_PATHS`.

## Разовий pull з хостингу

```bash
npm run pull:remote
```

Примітка: FTP pull синхронізує лише файли. Зміни в базі даних (налаштування модулів, контент із таблиць OpenCart) потрібно оновлювати окремо через dump/import БД.

## Поведінка браузера

`npm run dev` використовує Chrome Debug Protocol:
- відкриває або перевикористовує вкладку адмінки: `LIVE_RELOAD_URL/admin/`
- відкриває або перевикористовує вкладку вітрини: `LIVE_RELOAD_URL`
- після upload робить hard reload тільки вкладки вітрини (без кешу).

## Перенесення на інший хостинг

Якщо переносите сайт на новий хостинг (інші логіни/паролі), оновіть налаштування в такому порядку:

1. Оновіть спільний SFTP-конфіг у `.env.ftp.shared`:
- `FTP_HOST`, `FTP_PORT`, `FTP_USER`, `FTP_REMOTE_BASE`
- `LIVE_RELOAD_URL`
- `FTP_PASSWORD` лишайте порожнім у shared-файлі

2. Оновіть локальний пароль у `.env.ftp`:
- `FTP_PASSWORD=NEW_PASSWORD`

3. Оновіть доступ до БД:
- `config.php`
- `admin/config.php`

4. Перевірте синхронізацію:
```bash
npm run pull:remote
npm run dev
```

Примітка: якщо у PowerShell блокується `npm.ps1`, запускайте через:
```bash
cmd /c npm run pull:remote
cmd /c npm run dev
```

Примітка для `admin/config.php`: якщо новий хостинг не використовує `CONTEXT_DOCUMENT_ROOT`, переключіть шлях на варіант із `DOCUMENT_ROOT`.

## Командний Git-процес (конфлікти)

1. Працюйте у feature-гілках.
2. Перед PR синхронізуйте гілку з `main` і вирішіть конфлікти.
3. Ніколи не комітьте `.env.ftp`.
4. Комітьте код і контент, які мають бути спільними (`admin`, `catalog`, модулі, шаблони, стилі тощо).

## Файли цього налаштування

- `scripts/dev-sync.mjs` - watcher, FTP upload/pull, live reload
- `scripts/prepare-env.mjs` - автоматичне створення локального `.env.ftp`
- `scripts/sync-readme.mjs` - оновлення посилання Figma у README
- `.env.ftp.shared` - спільний конфіг проєкту в Git
- `.env.ftp.example` - універсальний шаблон для нового проєкту

## Використання в новому проєкті

Скопіюйте:
- `package.json`
- `scripts/dev-sync.mjs`
- `scripts/prepare-env.mjs`
- `scripts/sync-readme.mjs`
- `.env.ftp.shared` (з параметрами конкретного проєкту)
- `.env.ftp.example`

Потім виконайте:
```bash
npm install
npm run pull:remote
npm run dev
```

## .ftp-deploy-sync-state.json

`.ftp-deploy-sync-state.json` — це локальний службовий файл стану синхронізації, який використовує `npm run dev`.

- Зберігає метадані по кожному файлу: локальний hash, час останньої відомої зміни на FTP та джерело останнього sync (`upload`/`pull`).
- Потрібен для безпечного upload: якщо файл змінився і локально, і на сервері після останнього sync, завантаження пропускається з `CONFLICT`.
- Створюється та оновлюється автоматично під час `npm run dev` і `npm run pull:remote`.
- Це локальний runtime-файл, його не потрібно комітити в Git.
