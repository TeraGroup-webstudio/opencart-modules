#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import dotenv from "dotenv";

const readmePath = path.resolve("README.md");
const sharedPath = path.resolve(".env.ftp.shared");

try {
  const shared = fs.existsSync(sharedPath)
    ? dotenv.parse(fs.readFileSync(sharedPath, "utf8"))
    : {};
  const figmaUrl = (shared.FIGMA_URL || "").trim();
  if (figmaUrl && (!/^https?:\/\/\S+$/u.test(figmaUrl) || !URL.canParse(figmaUrl))) {
    throw new Error("FIGMA_URL must be an HTTP or HTTPS URL.");
  }

  const source = fs.readFileSync(readmePath, "utf8");
  const eol = source.includes("\r\n") ? "\r\n" : "\n";
  const bom = source.startsWith("\uFEFF") ? "\uFEFF" : "";
  const body = source.slice(bom.length);
  const heading = "# OpenCart FTP Live Sync (Node)";
  const prefix = "Макет Figma: ";
  const link = figmaUrl
    ? `[посилання](<${figmaUrl.replaceAll("<", "%3C").replaceAll(">", "%3E")}>)`
    : "посилання";
  const line = `${prefix}${link}`;
  let updated;

  if (body.startsWith(prefix)) {
    updated = figmaUrl
      ? bom + body.replace(/^[^\r\n]*/u, () => line)
      : bom + body.replace(/^[^\r\n]*(?:\r?\n){0,2}/u, "");
  } else if (body.startsWith(heading)) {
    updated = figmaUrl ? `${bom}${line}${eol}${eol}${body}` : source;
  } else {
    throw new Error("README.md: expected the Figma line or OpenCart heading at the start.");
  }

  if (updated !== source) {
    fs.writeFileSync(readmePath, updated, "utf8");
    console.log("Updated README.md from FIGMA_URL in .env.ftp.shared");
  }
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
