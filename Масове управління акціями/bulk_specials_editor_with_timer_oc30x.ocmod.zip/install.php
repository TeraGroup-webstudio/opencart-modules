<?php

$this->load->model('user/user_group');
$this->model_user_user_group->addPermission($this->user->user_group_id, 'modify', 'extension/module/timer');
