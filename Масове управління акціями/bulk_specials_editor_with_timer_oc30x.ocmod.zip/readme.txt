
! Notice that module spreads by the rule 1 domain = 1 licence.
! Respect developers' time and work, be honest.
! Enjoy.

English instruction

Installation:
1) Download the archive with module ("bulk_specials_editor_with_timer.ocmod.zip")
2) Upload the archive through the "Modification Installer" ("Modules -> Extension Installer)
3) Go to "Modules" -> "Modifications" click on the button "REFRESH" (modifications)

If you have problems with module installation, please send me email to dev.dashko@gmail.com


===========================
===========================
! Данный модуль распространяется по правилу 1 домен = 1 лицензия.
! Уважайте чужое время и труд, будьте честны.
! Наслаждайтесь.

Russian instruction (Русская инструкция).
	
Установка:
1) Для установки модуля нужно скачать архив "bulk_specials_editor_with_timer.ocmod.zip".
2) Загрузить архив через "Модули" -> "Установка расширений" -> Загрузить модуль.
3) После загрузки необходимо "Обновить модификации" в разделе "Модификации".

Если у вас проблемы с установкой, пожалуйста напишите на dev.dashko@gmail.com


Если вы используте UniShop тему, тогда перед установкой отредактируйте файл "install.xml":
	1) Раскомментируйте блок "Integration with UniShop theme"
		<!-- /* Integration with UniShop theme (should also disable "$price" replacement ) */ -->
		<operation error="log">
			<search><![CDATA[<li><span class="old_price">{{ price }}</span><span>{{ special }}</span></li>]]></search>
			<add position="replace"><![CDATA[<li><span class="old_price" style="{% if timer %} display: none; {% endif %}">{{ price }}</span><span>{{ special }}</span></li>]]></add>
		</operation>
		<operation error="log">
			<search index="1"><![CDATA[<hr />]]></search>
			<add position="replace"><![CDATA[]]></add>
		</operation>

	2) Закомментируйте следующий блок:
    	<!--
    		<operation error="log">
				<search><![CDATA[{% if price]]></search>
		    	<add position="replace"><![CDATA[{% if price and not timer]]></add>
		  	</operation>
		-->
