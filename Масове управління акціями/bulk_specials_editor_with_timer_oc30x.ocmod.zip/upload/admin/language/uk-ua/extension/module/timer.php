<?php
// Heading
$_['heading_title'] = '<b>Масове керування акціями + Таймер</b>';
$_['text_module']   = 'Модулі';
$_['text_edit']     = 'Налаштування модуля';

// Labels for TABs
$_['all_specials']                = 'Усі акції';
$_['general_settins']             = 'Основні';
$_['additional_settings']         = 'Додаткові';
$_['additional_settings_catalog'] = 'На сайті';
$_['additional_settings_admin']   = 'В адмін-панелі';
$_['set_specials']                = 'Встановлення акцій';
$_['edit_specials']               = 'Змінити акції';
$_['delete_specials']             = 'Видалення акцій';
$_['delete_all_specials']         = 'Видалити всі акції';
$_['support']                     = 'Підтримка';

# Tab 1 - All Specials
$_['hide_show_filters']   = 'Показати / Приховати фільтри';
$_['show_found_specials'] = 'Показати знайдені акції';
$_['show_found_products'] = 'Показати знайдені товари';
$_['show_more_records']   = 'Показати більше записів';
$_['shown']               = 'Показано';
$_['by_parameters']       = 'За параметрами';
$_['price']               = 'Ціна';
$_['name']                = 'Назва';
$_['product_name']        = 'Назва товару';
$_['text_category']            = 'Категорія';
$_['text_categories']          = 'Категорії';
$_['text_manufacturer']        = 'Виробник';
$_['text_manufacturers']       = 'Виробники';
$_['quantity']            = 'Кількість';
$_['status']              = 'Статус товару';

$_['old_price']     = 'Стара ціна';
$_['special_price'] = 'Акційна ціна';
$_['special_date']  = 'Дата акції';
$_['filter']        = 'Фільтрувати';
$_['clear_filters'] = 'Очистити фільтри';

$_['edit_selected_specials'] = 'Змінити вибрані акції';
$_['delete_chosen_specials'] = 'Видалити вибрані акції?';

$_['photo']           = 'Фото товару';
$_['qty']             = 'К-сть';
$_['date_start']      = 'Дата початку';
$_['date_end']        = 'Дата завершення';
$_['priority']        = 'Пріоритет';
$_['timer']           = 'Таймер';
$_['text_customer_group']  = 'Група покупців';
$_['text_customer_groups'] = 'Групи покупців';
$_['text_special_group']   = 'Група акцій';
$_['text_special_groups']  = 'Групи акцій';
$_['actions']         = 'Дії';

# Tab 2 - General Settings
$_['h3_timer_on_pages']         = 'Відображення таймера на сторінках:';
$_['timer_category_status']     = 'Сторінка категорії';
$_['timer_special_status']      = 'Сторінка акцій';
$_['timer_search_status']       = 'Сторінка пошуку';
$_['timer_manufacturer_status'] = 'Сторінка виробника';
$_['timer_product_status']      = 'Картка товару';

$_['h3_timer_in_modules']               = 'Відображення таймера в модулях:';
$_['timer_in_featured_module_status']   = 'Модуль "Рекомендовані"';
$_['timer_in_latest_module_status']     = 'Модуль "Останні надходження"';
$_['timer_in_special_module_status']    = 'Модуль "Акції"';
$_['timer_in_bestseller_module_status'] = 'Модуль "Хіт продажів"';

$_['timer_product_discount_label_status'] = 'Розмір знижки на сторінці картки товару';

# Tab 3 - Additional Settings
$_['display_columns'] = 'Відображення колонок на сторінці "Усі акції"';
$_['display_filters'] = 'Відображення фільтрів на сторінці "Усі акції"';
$_['clear_inputs']    = 'Очистити поля та зберегти';

# Tab 4 - Set Specials
$_['filter_by_parameters']                = 'Фільтр за параметрами';
$_['filter_by_products_parameters']       = 'Фільтр за параметрами товарів';
$_['filter_by_attribute_name_or_value']   = 'За назвою атрибута / або його значенням';
$_['filter_by_option_name_or_value']      = 'За назвою опції / або її значенням';
$_['placeholder_attribute_name_or_value'] = 'Назва атрибута | значення атрибута';
$_['placeholder_option_name_or_value']    = 'Назва опції | значення опції';
$_['include_additioanal_products']        = 'Додатково включити товари';
$_['special_parameters']                  = 'Параметри акції';
$_['found_products']                      = 'Знайдено товарів:';
$_['found_specials']                      = 'Знайдено акцій:';
$_['attribute_group']                     = 'Група атрибутів';
$_['total_discount']                      = 'Розмір знижки на товар';
$_['currency']                            = 'Знижка у грошовій одиниці';
$_['ignore_creation_if_special_exists']   = 'Не створювати акцію, якщо товар уже має акцію';
$_['set_specials_on_products']            = 'Встановити акції на товари';

# Tab 5 - Delete Specials
$_['delete_specials'] = 'Видалити акції';

# Error/Success labels
$_['no_results']                      = 'Немає акційних товарів';
$_['error_products_not_found']        = 'Товари не знайдені або вже мають акції';
$_['error_no_selected_specials']      = 'Акції не вибрані';
$_['error_no_selected_products']      = 'Товари не вибрані';
$_['error_no_selected_categories']    = 'Не вибрані категорії';
$_['error_no_selected_manufacturers'] = 'Не вибрані виробники';
$_['error_percentage_discount']       = 'Знижка у % має бути в межах 0-100. ';
$_['error_total_discount']            = 'Вказано неправильний розмір знижки';
$_['error_min_discount']              = 'Розмір знижки має бути > 0. ';
$_['error_discount']                  = 'Неправильно задана знижка.';
$_['error_price']                     = 'Неправильно вказана ціна. ';
$_['error_exceeding_price_limit']     = 'Акційна ціна не може бути більшою за звичайну ціну. ';
$_['error_exceeding_date_period']     = 'Дата початку акції не може бути пізнішою за дату завершення акції. ';
$_['error_permission']                = 'У вас немає прав змінювати налаштування цього модуля!';
$_['error_empty_customer_groups']     = 'Групи покупців не вказані. ';

$_['delete_hint']                       = 'Ця дія незворотна. Ви впевнені?';
$_['successfully_deleted_specials']     = 'Акції успішно видалені.';
$_['successfully_deleted_all_specials'] = 'Усі акції були успішно видалені.';
$_['failed_deleted_all_specials']       = 'Усі акції не були видалені.';

$_['successfully_edited_specials']                = 'Акції для наступних товарів були успішно змінені:';
$_['error_price_exceeding_for_selected_specials'] = 'Акції для наступних товарів не були змінені, оскільки акційна ціна перевищує звичайну ціну товару: ';

$_['successfully_added_specials']    = 'Акції для наступних товарів були успішно додані:';
$_['error_price_exceeding_products'] = 'Акції для наступних товарів не були додані, оскільки акційна ціна перевищує звичайну ціну товару: ';

$_['successfully_deleted_chosen_specials'] = 'Вибрані акції успішно видалені';

$_['data_has_errors'] = 'У даних є помилки';

# ==================
# Other Labels
$_['save']                        = 'Зберегти';
$_['save_settings']               = 'Зберегти налаштування';
$_['settings_saved_successfully'] = 'Налаштування успішно збережені';
$_['edit']                        = 'Редагувати';
$_['refresh']                     = 'Оновити сторінку';
$_['cancel']                      = 'Скасувати';
$_['on']                          = 'Увімк.';
$_['off']                         = 'Вимк.';
$_['from']                        = 'Від';
$_['to']                          = 'До';
$_['select_all']                  = 'Вибрати все';
$_['unselect_all']                = 'Зняти виділення';
$_['by_categories']               = 'За категоріями';

$_['model']           = 'Модель';
$_['by_product_name'] = 'За назвою товару';
$_['by_model']        = 'За моделлю';

$_['by_manufacturers']                     = 'За виробниками';
$_['weekdays']                             = 'Дні тижня';
$_['hours']                                = 'Години';
$_['always']                               = 'Завжди';
$_['choose']                               = ' -- Оберіть -- ';
$_['text_overwrite']                            = '<span data-toggle="tooltip" title="" data-original-title="Перезаписати інформацію.<br>Інакше інформація не буде змінена.">Перезаписати</span> ';
$_['specials_without_special_groups']      = 'Акції без вказаної групи';
$_['label_group_name']                     = 'Введіть назву групи';
$_['group_name']                           = 'Назва групи';
$_['add_group']                            = 'Додати групу';
$_['delete_selected_group']                = 'Видалити вибрану групу';
$_['new_special_group_successfully_added'] = 'Нова група акцій "%s" була успішно додана.';
$_['special_group_successfully_renamed']   = 'Група акцій "%s" була успішно перейменована.';
$_['special_group_successfully_deleted']   = 'Група акцій "%s" успішно видалена';
$_['error_special_group_name']             = 'Назва групи акцій не може бути порожньою або довшою за 100 символів.';

// ==============================
// Додаткові налаштування на сайті
$_['h4_detailed_product_page_settings']     = 'Налаштування таймера та бейджа на сторінці картки товару';
$_['h4_settings_in_other_sections_of_site'] = 'Налаштування відображення таймера в інших розділах магазину (категорії, сторінка акцій, у модулях тощо)';
$_['badge_color']                           = 'Колір бейджа';
$_['badge_font_size']                       = 'Розмір тексту в бейджі';
$_['badge_top']                             = 'Верхній відступ у бейджі';
$_['badge_font_weight']                     = 'Товщина (жирність) тексту в бейджі';

$_['special_price_color']     = 'Колір акційної ціни';
$_['special_price_font_size'] = 'Розмір тексту акційної ціни';
$_['special_price_margin']    = 'Зовнішні відступи акційної ціни';
$_['old_price_color']         = 'Колір старої ціни';
$_['old_price_size']          = 'Розмір тексту старої ціни';
$_['old_price_margin']        = 'Зовнішні відступи старої ціни';

$_['product_timer_price_block_border_size']    = 'Товщина рамки блоку з таймером і ціною';
$_['product_timer_price_block_border_color']   = 'Колір рамки блоку з таймером і ціною';
$_['product_timer_price_block_padding']        = 'Внутрішні відступи у блоці з таймером і ціною';
$_['product_timer_price_block_margin']         = 'Зовнішні відступи у блоці з таймером і ціною';
$_['product_timer_price_block_full_width']     = 'Показати блок з таймером і ціною на всю ширину';
$_['product_timer_block_timer_text']           = 'Внутрішні відступи у блоці з таймером';
$_['product_timer_block_timer_text_font_size'] = 'Розмір тексту напису над таймером';

$_['countdown_border_size']      = 'Товщина рамки блоку таймера';
$_['countdown_border_color']     = 'Колір рамки блоку таймера';
$_['countdown_background_color'] = 'Фон блоку таймера';
$_['countdown_text_color']       = 'Колір тексту в таймері';
$_['countdown_margin']           = 'Зовнішні відступи таймера';
$_['countdown_padding']          = 'Внутрішні відступи таймера';
$_['countdown_amount_font_size'] = 'Розмір шрифту цифр у таймері';
$_['countdown_period_size']      = 'Розмір шрифту підписів у таймері';

$_['timer_block_percentage_discount_full_width'] = 'Показати блок зі знижкою на всю ширину';
$_['timer_block_percentage_discount_margin']     = 'Зовнішні відступи блоку зі знижкою';
$_['timer_block_percentage_discount_background'] = 'Фон блоку зі знижкою';
$_['timer_block_percentage_discount_color']      = 'Колір тексту в блоці зі знижкою';
$_['timer_block_percentage_discount_font_size']  = 'Розмір тексту в блоці зі знижкою';
