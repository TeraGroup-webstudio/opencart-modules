<?php

// Text
$_['text_timer_on_products_page']  = 'Знижка ';
$_['text_timer_ended'] = 'Знижка завершилась.'; // для js файлу
$_['text_timer_lang'] = 'ukrainian';
$_['text_timer_heading'] = 'Акційна ціна діє';
