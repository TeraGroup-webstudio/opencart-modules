<?php

class ControllerExtensionModuleSpproProductGroups extends Controller
{
    public function index()
    {
        if ($this->config->get('module_sppro_product_group_main_product_replace')) {
            if (isset($this->request->get['action']) && $this->request->get['action'] == 'main_products') {
                return $this->getMainProducts();
            } else {
                echo 'Not found';
            }
        } else {
            echo 'Not found';
        }
		echo 'Not found';
		exit(0);
    }

    public function getGroupProducts($product_group_id)
    {
        $array = [];
        $products = $this->db->query('SELECT * FROM ' . DB_PREFIX . 'sppro_group_product_group_products WHERE product_group_id = ' . $product_group_id);
        foreach ($products->rows as $product) {
            $stock_count = $this->getProductStock($product['product_id']);
            if ($stock_count >= 1) {
                $array[] = ['product_id' => $product['product_id'], 'quantity' => $this->getProductStock($product['product_id'])];
            }
        }
        return $array;
    }

    public function updateGroupMainProductId($product_group_id, $product_id)
    {
        $this->db->query("UPDATE " . DB_PREFIX . "sppro_group_product_group SET main_product_id = " . (int)$product_id . " WHERE product_group_id = " . (int)$product_group_id);
        return true;
    }

    public function getProductStock($product_id)
    {
        $product_id = (int)$product_id;
        $query = $this->db->query("SELECT quantity AS qat FROM " . DB_PREFIX . "product WHERE product_id = $product_id");
        if (!$query->num_rows) {
            return 0;
        }
        return (int)$query->row['qat'];
    }

    public function getMainProducts()
    {
        $product_groups = $this->db->query('SELECT * FROM ' . DB_PREFIX . 'sppro_group_product_group WHERE main_product_id IS NOT NULL');
        foreach ($product_groups->rows as $product_group) {
            if ($product_group['main_product_id']) {
                if ($this->getProductStock($product_group['main_product_id']) <= 0) {
                    $group_products = $this->getGroupProducts($product_group['product_group_id']);
                    if (!empty($group_products)) {
                        $max_quantity = 0;
                        $max_product_id = null;
                        foreach ($group_products as $product) {
                            if ($product['quantity'] > $max_quantity) {
                                $max_quantity = $product['quantity'];
                                $max_product_id = $product['product_id'];
                            }
                        }
                        if ($max_product_id !== null) {
                            $this->updateGroupMainProductId($product_group['product_group_id'], $max_product_id);
                        }
                    }
                }
            }
        }
        return 'Done';
    }

    public function getProductForList()
    {
        if (isset($this->request->get['product'])) {

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $result = $this->model_catalog_product->getProduct($this->request->get['product']);

            if ($result) {

                if (isset($this->request->get['list_type'])) {
                    $data['list_type'] = $this->request->get['list_type'];
                } else {
                    $data['list_type'] = '';
                }

                if ($result['image']) {
                    $image = $this->model_tool_image->resize($result['image'], $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_height'));
                } else {
                    $image = $this->model_tool_image->resize('placeholder.png', $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_product_height'));
                }

                if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
                    $price = $this->currency->format($this->tax->calculate($result['price'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
                } else {
                    $price = false;
                }

                if (!is_null($result['special']) && (float)$result['special'] >= 0) {
                    $special = $this->currency->format($this->tax->calculate($result['special'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
                    $tax_price = (float)$result['special'];
                } else {
                    $special = false;
                    $tax_price = (float)$result['price'];
                }

                if ($this->config->get('config_tax')) {
                    $tax = $this->currency->format($tax_price, $this->session->data['currency']);
                } else {
                    $tax = false;
                }

                if ($this->config->get('config_review_status')) {
                    $rating = (int)$result['rating'];
                } else {
                    $rating = false;
                }

                $result = (isset($product_info) && $product_info) ? $product_info : $result;

                if ($result['quantity'] <= 0) {
                    $stock = $result['stock_status'];
                } else {
                    $stock = false;
                }

                $data['product'] = array(
                    'product_id' => $result['product_id'],
                    'thumb' => $image,
                    'name' => $result['name'],
                    'description' => utf8_substr(trim(strip_tags(html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8'))), 0, $this->config->get('theme_' . $this->config->get('config_theme') . '_product_description_length')) . '..',
                    'price' => $price,
                    'special' => $special,
                    'stock' => $stock,
                    'tax' => $tax,
                    'product_group' => $this->model_catalog_product->getProductGroupsForList($result['product_id'], true),
                    'minimum' => $result['minimum'] > 0 ? $result['minimum'] : 1,
                    'rating' => $this->config->get('config_review_status') ? $result['rating'] : false,
                    'reviews' => $result['reviews'],
                    'quantity' => $result['quantity'] <= 0 ? true : false,
                    'href' => $this->url->link('product/product', 'product_id=' . $result['product_id'])
                );

                $this->response->setOutput($this->load->view('extension/module/sppro_product_group/sppro_product_groups_list', $data));
            }
        }
    }
}