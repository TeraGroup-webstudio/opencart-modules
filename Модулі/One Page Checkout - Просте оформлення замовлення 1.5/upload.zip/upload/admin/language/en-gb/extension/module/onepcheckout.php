<?php
// header
$_['heading_title'] 							= '[29aleksey] - One page checkout';

//Text
$_['text_type_tel_mask']                = 'Mask Type';
$_['text_standart_mask']                = 'Standard';
$_['text_multi_mask']                   = 'Multi';
$_['text_geoip_auto_detect']            = 'Detect Country by IP';
$_['text_initial_country']              = 'Default Country';
$_['text_exclude_countries']            = 'Exclude Countries';
$_['text_only_countries']               = 'Only Selected Countries';
$_['text_help_countries']               = 'List all countries by their country code, separated by commas, in lowercase!';
$_['text_info']                         = 'Information';
$_['text_info_multi_mask']              = 'This feature is based on the International Telephone Input plugin. Country codes should be in Alpha-2 format (two-letter code),</br>which can be found <a href="https://www.geonames.org/countries/">here</a> or in "System -> Localization -> Countries". </br>Add country codes separated by commas in lowercase letters.';
$_['text_email_default_on_empty']       = 'Default email if it is empty or optional';
$_['text_show_contact_telegram_viber']  = 'Contact via Telegram/Viber';

$_['entry_image']   							= 'Image';
$_['text_tel_validation']   				= 'Regular expression for validating phone numbe';
$_['text_example']   						= 'Example: ';
$_['entry_status_pm_title']				= 'Change payment method name';
$_['entry_status_pm_description']		= 'Display a description under the payment method';
$_['entry_method_title']					= 'Method name';
$_['entry_pm_description']					= 'Description [displayed under the selected payment method]';
$_['entry_status_sm_title']				= 'Change shipping method name';

$_['button_apply']							= 'Apply';
$_['text_block_free_text']					= 'Free text';
$_['tab_shipping_methods']					= 'Shipping Methods';
$_['text_free_shipping'] 					= 'Free shipping left.';
$_['entry_free_shipping_price'] 			= 'Free shipping from';
$_['text_shipping_method_available'] 	= 'Shipping available [Country and Region block must be enabled]';
$_['entry_sm_show_all_countries'] 		= 'For all countries';
$_['entry_sm_show_only_countries'] 		= 'Only for selected countries';
$_['entry_sm_disabled_for_countries'] 	= 'Do not show for countries';
$_['text_block_country_region'] 			= 'Country and Region';
$_['text_block_related_products'] 		= 'Recommended product';
$_['text_edit_related_products'] 		= 'Recommended products settings';
$_['text_related_products_title'] 		= 'Title';
$_['entry_image_wh'] 						= 'Image Width x Height';
$_['entry_width'] 							= 'Width';
$_['entry_height'] 							= 'Height';
$_['entry_limit'] 							= 'Limit';
$_['entry_type_product_display'] 		= 'Which product to display?';
$_['text_related_product'] 				= 'Related Product';
$_['text_featured_product'] 				= 'Featured product';
$_['text_info_related_products'] 		= 'You can add related products in each product in the [Relations] tab';
$_['entry_shuffle_products'] 				= 'Shuffle products?';
$_['entry_register'] 						= 'Registration';
$_['text_register_default'] 				= 'Choice';
$_['text_register_required'] 				= 'Required';
$_['text_register_disabled'] 				= 'No registration';

$_['text_show_weight']						= 'Products weight';
$_['text_show_not_call_me']				= 'Don\'t call me, I\'m sure of the order.';

$_['text_tab_custom_field']				= 'Custom fields';
$_['text_custom_field']						= 'Custom field';
$_['text_edit_custom_field']				= 'Edit Custom field';
$_['text_add_custom_field']				= 'Add Custom field';
$_['text_choose']								= 'Choose';
$_['text_select']								= 'Select';
$_['text_radio']								= 'Radio';
$_['text_checkbox']							= 'Checkbox';
$_['text_input']								= 'Input';
$_['text_text']								= 'Text';
$_['text_textarea']							= 'Textarea';
$_['text_date']								= 'Date';
$_['text_datetime']							= 'Date &amp; Time';
$_['text_time']								= 'Time';
$_['text_customer']							= 'Customer';
$_['text_address']							= 'Address';
$_['text_payment']							= 'Payment';
$_['text_regex']								= 'Regex';
$_['text_loading']							= 'Loading...';
$_['text_saving']								= 'Saving...';
$_['text_no_results']						= 'No custom fields';
$_['text_custom_field_confirm']			= 'This field already exists! Replace?';
$_['text_field_save_to_comment']			= 'Save field value in order comment';

// Button
$_['button_create_field']					= 'Add Field';
$_['button_add_element']					= 'Add Element';

// Column
$_['column_name']           				= 'Name';
$_['column_location']       				= 'Location';
$_['column_type']           				= 'Type';
$_['column_status']           			= 'Status';
$_['column_action']         				= 'Action';

//Entry
$_['entry_name']								= 'Name';
$_['entry_location']							= 'Location';
$_['entry_type']								= 'Type';
$_['entry_value']								= 'Value';
$_['entry_validation']						= 'Validation';
$_['entry_custom_value']					= 'Custom Field Value Name';
$_['entry_customer_group']					= 'Customer Group';
$_['entry_required']							= 'Required';
$_['entry_status']							= 'Status';
$_['entry_sort_order']						= 'Sort Order';
$_['entry_text_error']						= 'Text Error';

// Help
$_['help_regex']           				= 'Use regex. E.g: /[a-zA-Z0-9_-]/';
$_['help_sort_order']      				= 'Use minus to count backwards from the last field in the set.';

//Error
$_['text_success_add_cfield']				= 'You have successfully created a custom field.';
$_['text_success_edit_cfield']			= 'You have successfully modified a custom field.';
$_['text_success_remove_cfield']			= 'You have successfully delete a custom field.';
$_['error_name']								= 'The field name must be from 1 to 128 characters!';
$_['error_type']								= 'You must specify a value!';
$_['error_custom_value']					= 'The value must be between 1 and 128 characters!';
$_['error_location']							= 'The "Location" field cannot be changed because it is used in the section';


$_['text_entry_value'] 						= 'Enter value';
$_['entry_left_column_val'] 				= 'Left column';
$_['entry_right_column_val'] 				= 'Right column';
$_['text_block_top_full'] 					= 'Full Width Top';
$_['text_block_bottom_full'] 				= 'Full Width Bottom';
$_['text_column_width'] 					= 'Column width';

$_['text_tab_payment'] 						= 'Payment methods';
$_['entry_status_payment_quest'] 		= 'Option available to guests';
$_['entry_status_payment_authorized'] 	= 'Option available to authorized users';
$_['help_payment_quest'] 					= 'Enable or disable this payment method for guests';
$_['help_payment_authorized'] 			= 'Enable or disable this payment method for authorized users';
$_['entry_payment_shipping_methods'] 	= 'The option is available for the selected shipping methods:';
$_['text_for_all_shipping'] 				= 'Available for all shipping methods.';
$_['text_payment_methods'] 				= 'Payment options';
$_['title_opc_payment'] 					= 'Restrict payment options visibility';
$_['text_empty_payment_method'] 			= 'No payment methods available';
$_['text_payment_confirm'] 				= 'This Payment method has already been added! Replace ?';

// Text
$_['text_module'] 							= 'Modules';
$_['text_success'] 							= 'Settings changed successfully!';
$_['text_edit'] 								= 'Module settings';
$_['text_phone_mask'] 						= 'Phone mask ( +38(099) 999-99-99 )';
$_['text_min_price_order'] 				= 'Minimum order amount';
$_['text_agree_default'] 					= 'Agreement terms are selected by default';

$_['text_tab_general'] 						= 'General';
$_['text_tab_block'] 						= 'Block Builder';
$_['text_tab_details'] 						= 'Personal details';
$_['text_tab_comment'] 						= 'Comment';
$_['text_tab_delivery'] 					= 'Delivery address';
$_['text_tab_javascript'] 					= 'Javascript';
$_['text_javascript_info'] 				= 'Javascript code - after updating blocks';
$_['text_disabled'] 							= 'Disabled';
$_['text_enabled_required'] 				= 'Enabled * [required]';
$_['text_enabled_no_required'] 			= 'Enabled not required';

$_['entry_type'] 								= 'Field type';
$_['text_select'] 							= 'List (Select)';
$_['text_select2'] 							= 'List (Select2)';
$_['text_radio'] 								= 'Switch (Radio)';
$_['text_checkbox'] 							= 'Checkbox (Checkbox)';
$_['text_input'] 								= 'Input';
$_['text_write_to'] 							= 'Write to';
$_['text_type_action'] 						= 'Action with value';
$_['text_cinfo_type_action'] 				= 'When placing an order, append the value of this field to another field. Example: [Field Patronymic (It’s the same as the Fax field) - Add to the Surname field]';
$_['text_action_field'] 					= 'Available field options for the entry';

$_['text_customer_firstname'] 			= 'Name';
$_['text_customer_lastname'] 				= 'Lastname';
$_['text_customer_telephone'] 			= 'Phone';
$_['text_customer_email'] 					= 'Email';
$_['text_customer_fax'] 					= 'Fax';

$_['text_address_country'] 				= 'Country';
$_['text_address_zones'] 					= 'Region';
$_['text_address_zone_id'] 				= 'Region';
$_['text_address_company'] 				= 'Company';
$_['text_address_address_1'] 				= 'Address';
$_['text_address_address_2'] 				= 'Address 2';
$_['text_address_city'] 					= 'City';
$_['text_address_postcode'] 				= 'Postcode';
$_['text_shipping_address'] 				= 'Shipping address';
$_['entry_status'] 							= 'Status';
$_['text_status_description'] 			= 'Do you want to enable built-in easy checkout?';
$_['text_yes'] 								= 'Yes';
$_['text_no'] 									= 'No';
$_['text_field_name'] 						= 'Name';
$_['text_placeholder'] 						= 'Placeholder';
$_['text_shipping_options'] 				= 'Shipping Options';
$_['text_cart'] 								= 'Cart';
$_['text_sorts_field'] 						= 'Drag to change sort';
$_['entry_custom_value'] 					= 'Value';
$_['text_default'] 							= 'Default';
$_['text_default_select_cfv'] 			= 'Default value';
$_['text_field_error'] 						= 'Error text';
$_['text_all_client'] 						= 'Show to all';
$_['text_only_quest'] 						= 'Guests only';
$_['text_only_authorized'] 				= 'Only for authorized';
$_['entry_product'] 							= 'Add Product';

$_['text_block_cart'] 						= 'Cart';
$_['text_block_customer'] 					= 'Customer';
$_['text_block_shipping_method'] 		= 'Shipping method';
$_['text_block_payment_method'] 			= 'Payment Method';
$_['text_block_shipping_address'] 		= 'Shipping address';
$_['text_block_comment']					= 'Comment';
$_['text_block_totals'] 					= 'Coupon / Certificate / Total';
$_['text_block_totals_title'] 			= 'Fix block on page scroll';


$_['text_empty_shipping_methods'] 		= 'There are no shipping methods available.';
$_['text_shipping_confirm'] 				= 'This shipping method has already been added! Replace ?';
$_['button_search'] 							= 'Search';
$_['button_add_value'] 						= 'Add value';

// Help
$_['help_product'] 							= '(AutoComplete)';

// error
$_['error_no_found_shipping_methods']  = 'There are no other shipping methods based on the given parameters.';
$_['error_permission'] 						= 'You do not have permission to manage this module!';

$_['add_activation_key']					= 'Enter license key';
$_['heading_title_activation']			= 'Activation';
$_['activated_btn']							= 'Activate';
$_['the_module_is_activated']				= 'Module Activated!';
