<?php
// Heading
$_['text_not_call_me']						= 'Не звоните, я уверен в заказе';
$_['text_contact_telegram_viber'] 		= 'Свяжитесь через Telegram/Viber';
$_['text_model']								= 'Код товара: ';
$_['text_out']									= 'Нет в достаточном количестве!';
$_['text_i_am_registered']					= 'Я зарегистрирован';
$_['text_op_customer']						= 'Покупатель';
$_['title_shipping_method']				= 'Способ Доставки';
$_['title_payment_method']					= 'Способ Оплаты';
$_['title_shipping_address']				= 'Адрес доставки';
$_['text_min_totals_order']				= 'Минимальная сумма заказа - %s';
$_['title_country_region']					= 'Страна и Регион';
$_['text_free_shipping_left']				= '<div class="text-free-shipping">До бесплатной доставки осталось</div> <span class="sum-free-shipping-left">%s</span>';
$_['text_free_shipping']					= 'Бесплатная доставка';
$_['text_you_order'] 						= 'Ваш заказ';
$_['text_reward'] 							= '<span>Использовать бонусные баллы</span> <span class="reward-body"><span class="reward-available">Доступно:</span> <span class="reward-amount">%s</span></span>';
$_['text_coupon'] 							= 'Промокод';
$_['text_gift'] 							  = 'Ваш подарок к заказу 🔥';
$_['text_voucher'] 							= 'Сертификат';
$_['entry_coupon']							= 'Введите код промокода';
$_['entry_voucher']							= 'Введите код сертификата';
$_['column_price']							= 'За 1 шт:';

$_['text_login']								= 'Авторизация';
$_['text_register']							= 'Регистрация';
$_['text_forgotten']							= 'Забыли пароль?';
$_['entry_email']								= 'Email';
$_['entry_password']							= 'Пароль';

// Error
$_['error_login']								= 'Неправильно заполнены поля Email и/или пароль!';
$_['error_attempts']							= 'Внимание: Вы превысили допустимое количество попыток входа в систему. Пожалуйста, попробуйте через час.';
$_['error_approved']							= 'Необходимо подтвердить аккаунт перед авторизацией.';
$_['error_register']							= 'Заказ доступен только для зарегистрированных клиентов.';
$_['error_format_telephone']				= 'Неправильний формат номера телефона!';
