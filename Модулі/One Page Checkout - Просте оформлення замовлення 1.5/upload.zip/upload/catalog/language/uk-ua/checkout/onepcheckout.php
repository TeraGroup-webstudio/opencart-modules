<?php
// Heading
$_['text_not_call_me']						= 'Не дзвонити, я впевнений у замовленні';
$_['text_contact_telegram_viber'] 		= 'Зв\'яжіться через Telegram/Viber';
$_['text_model']								= 'Код товару: ';
$_['text_out']									= 'Немає в достатній кількості!';
$_['text_i_am_registered']					= 'Я зареєстрований';
$_['text_op_customer']						= 'Покупець';
$_['title_shipping_method']   			= 'Спосіб доставки';
$_['title_payment_method']   				= 'Спосіб оплати';
$_['title_shipping_address']   			= 'Адреса доставки';
$_['text_min_totals_order']            = 'Мінімальна сума замовлення - %s';
$_['title_country_region'] 				= 'Країна та Регіон';
$_['text_free_shipping_left'] 			= '<div class="text-free-shipping">До безкоштовної доставки залишилося</div> <span class="sum-free-shipping-left">%s</span>' ;
$_['text_free_shipping'] 					= 'Безкоштовна доставка';
$_['text_you_order'] 						= 'Ваше замовлення';
$_['text_reward'] 							= '<span>Використати бонусні бали</span> <span class="reward-body"><span class="reward-available">Доступно:</span> <span class="reward-amount">%s</span></span>';
$_['text_coupon'] 							= 'Промокод';
$_['text_gift'] 							  = 'Ваш подарунок до замовлення 🔥';
$_['text_voucher'] 							= 'Сертифікат';
$_['entry_coupon']							= 'Введіть код промокоду';
$_['entry_voucher']							= 'Введіть код сертифіката';
$_['column_price']							= 'За 1 шт:';

$_['entry_email']								= 'Email';
$_['entry_password']							= 'Пароль:';
$_['text_login']                   		= 'Авторизація';
$_['text_register']                		= 'Реєстрація';
$_['text_forgotten']               		= 'Забули пароль?';

// Error
$_['error_login']								= 'Неправильно заповнені поля Email та / або пароль!';
$_['error_attempts']							= 'Ви перевищили допустиму кількість спроб входу в систему. Будь ласка, спробуйте через годину.';
$_['error_approved']							= 'Необхідно підтвердити обліковий запис перед авторизацією.';
$_['error_register']							= 'Замовлення доступне тільки для зареєстрованих клієнтів.';
$_['error_format_telephone']				= 'Неправильний формат телефону!';
