<?php
class ModelLocalisationShopAddress extends Model {

    public function getShopAddresses() {
        $this->ensureTablesExist();

        $sql = "SELECT sa.shop_address_id, sad.name, sad.address, sa.phone
                FROM " . DB_PREFIX . "shop_address sa
                LEFT JOIN " . DB_PREFIX . "shop_address_description sad
                    ON (sa.shop_address_id = sad.shop_address_id)
                WHERE sad.language_id = '" . (int)$this->config->get('config_language_id') . "'
                AND sa.status = '1'
                ORDER BY sa.sort_order ASC";

        return $this->db->query($sql)->rows;
    }

    private function ensureTablesExist() {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "shop_address` (
            `shop_address_id` int(11) NOT NULL AUTO_INCREMENT,
            `phone` varchar(64) NOT NULL DEFAULT '',
            `status` tinyint(1) NOT NULL DEFAULT '1',
            `sort_order` int(11) NOT NULL DEFAULT '0',
            `date_added` datetime NOT NULL,
            `date_modified` datetime NOT NULL,
            PRIMARY KEY (`shop_address_id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8");

        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "shop_address_description` (
            `shop_address_id` int(11) NOT NULL,
            `language_id` int(11) NOT NULL,
            `address` text NOT NULL,
            `name` varchar(255) NOT NULL,
            PRIMARY KEY (`shop_address_id`, `language_id`),
            KEY `language_id` (`language_id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8");
    }

}
