<?php

/*!
 * All rights to the module are reserved and belong to the module developers SAP https://doc.sapas.pw
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source!
 * Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license our resources.
 *
 * DISCLAIMER
 *
 * Do not edit or add anything to this file if you want to update the module to newer versions in the future.
 *
 * @author		SAP
 * @copyright	SAP
 * @license		Valid for 1 website (or project) for each purchase of license
 */

class ControllerExtensionModuleSociallogin extends Controller
{
	private $path			= 'extension/module/sociallogin';
	private $my_model		= 'model_extension_module_sociallogin';
	private $setting		= [];
	private $socials		= ['Facebook', 'Twitter', 'Google', 'Telegram', 'Apple', 'LinkedIn', 'Discord', 'Reddit'];
	private $isVersion3Plus	= false;
	private $providersCache	= null;

	public function __construct($registry)
	{
		parent::__construct($registry);

		$this->isVersion3Plus = version_compare(VERSION, '3', '>=');
		$this->load->language($this->path);
		$this->load->model($this->path);

		$this->setting = $this->cache->get('sociallogin_setting');

		if (!$this->setting) {
			$this->load->model('setting/setting');
			$this->setting = $this->model_setting_setting->getSetting('sociallogin');
			$this->cache->set('sociallogin_setting', $this->setting);
		}
	}

	public function index()
	{
		if ($this->customer->isLogged()) {
			if (!isset($this->setting['sociallogin_account']) || !$this->setting['sociallogin_account']) {
				return;
			}

			if (isset($this->request->get['route']) && preg_match('/^account\/(edit|simpleedit)$/i', $this->request->get['route'])) {
				if (isset($this->session->data['provider']) && isset($this->session->data['userProfile'])) {
					$userProfile = $this->session->data['userProfile'];
					$this->trackingUser($this->customer->getId());

					if (($email = $this->{$this->my_model}->getIdentifier($userProfile['identifier'])) !== null) {
						$this->trackingLogin($email);
					}
					
					$redirectRoute = (strpos($this->request->get['route'], 'simple') !== false) ? 'account/simpleedit' : 'account/edit';
					$this->response->redirect($this->url->link($redirectRoute));
				}
			}

			return;
		}

		if (isset($this->session->data['provider']) && isset($this->session->data['userProfile'])) {
			$redirectUrl = (isset($this->request->get['route']) && strpos($this->request->get['route'], 'logout') !== false) ? $this->url->link('account/account') : $this->socia_llogin->getCurrentUrl();
			$userProfile = $this->session->data['userProfile'];
			$this->setting['provider'] = $this->session->data['provider'];

			if (isset($userProfile['email']) || in_array($this->setting['provider'], ['Telegram', 'Reddit'])) {
				$this->load->model('account/customer');
				if (($email = $this->{$this->my_model}->getIdentifier($userProfile['identifier'])) !== null) {
					$this->handleExistingCustomer($email);
					$this->response->redirect($redirectUrl);
				}

				if (empty($userProfile['email']) || !$this->model_account_customer->getTotalCustomersByEmail($userProfile['email'])) {
					if ((isset($this->setting['sociallogin_additional']) && $this->setting['sociallogin_additional']) || in_array($this->setting['provider'], ['Telegram', 'Reddit']) || empty($userProfile['email'])) {
						return $this->generateAdditionalForm($userProfile);
					} else {
						$redirectUrl = $this->addCustomer((int)$this->config->get('config_customer_group_id'), $userProfile);
					}
				} else {
					$this->handleExistingCustomer($userProfile['email']);
				}
			}

			$this->response->redirect($redirectUrl);
		}

		$setting = $this->setting;

		if (isset($setting) && isset($setting['sociallogin_status']) && isset($setting['sociallogin_popuplogin'])) {
			$data = $this->load->language($this->path);

			$data['account']			= 'login';
			$data['value_custom_field']	= isset($this->request->post['custom_field']['account']) ? $this->request->post['custom_field']['account'] : [];
			$data['captcha']			= '';
			$data['register_captcha']	= in_array('register', (array)$this->config->get('config_captcha_page')) ? true : false;

			$captchaConfigKey = $this->isVersion3Plus ? 'captcha_' . $this->config->get('config_captcha') . '_status' : $this->config->get('config_captcha') . '_status';

			if ($this->config->get($captchaConfigKey) && $data['register_captcha']) {
				$data['captcha'] = $this->load->controller($this->path . '/' . ($this->config->get('config_captcha') . ($this->isVersion3Plus ? '_captcha' : '')));
			}

			$this->loadCustomerGroups($data);

			$customFields	= $this->{$this->my_model}->getCustomFields();
			$fieldValue		= array_fill_keys(array_keys($this->config->get('sociallogin_rawfields')), '');
			$field_data		= $this->socia_llogin->getBuildingFields($setting, 'sociallogin_register_fields', $fieldValue);

			foreach ($customFields as $customField) {
				if ($customField['location'] == 'account') {
					$field_data[$customField['custom_field_id']] = $customField;
					$field_data[$customField['custom_field_id']]['custom_field'] = true;
					$field_data[$customField['custom_field_id']]['enabled'] = true;
				}
			}

			$this->socia_llogin->loadScriptAndStyle($field_data);

			$data['fields']				= $this->socia_llogin->sortFields($field_data, $data['customer_groups']);
			$data['text_agree']			= !empty($field_data['agree']['enabled']) ? $this->getAgreements() : '';
			$data['display_newsletter']	= $field_data['newsletter']['enabled'];

			$this->processSLSettings($data, $setting);

			$data['sl_shortcode'] = [];
			$data['setting'] = $sl_data['setting'] = $setting;
			$sl_data['popup'] = false;

			$languageId = $this->config->get('config_language_id');

			foreach (['login', 'reg'] as $position) {
				$sl_data['position'] = $position;

				if ($setting['sociallogin_button'][$position] != 'icon') {
					$this->load->model('tool/image');
				}

				$sl_data['sociallogin_titlelogin'][$position] = isset($setting['sociallogin_titlelogin'][$position][$languageId])
					? $setting['sociallogin_titlelogin'][$position][$languageId]
					: '';

				foreach ($this->socials as $key) {
					$provider = mb_strtolower($key);

					$sl_data['providers'][$position][] = $key;
					$sl_data[$provider . 'status'][$position] = !empty($setting['sociallogin_' . $provider . 'status']) && !empty($setting['sociallogin_to_use_' . $position][$provider]);
					$sl_data['sociallogin_' . $provider . 'title'][$position] = isset($setting['sociallogin_' . $provider . 'title'][$position][$languageId])
						? $setting['sociallogin_' . $provider . 'title'][$position][$languageId]
						: '';

					if ($setting['sociallogin_button'][$position] != 'icon') {
						$sl_data['sociallogin_' . $provider . 'image'][$position] = $this->getProviderImage($setting, $provider, $position);
					}
				}

				$data['sl_shortcode'][$position] = $this->socia_llogin->renderView($this->path . '/sl_shortcode', $sl_data);
			}
			
			$data['sap_otp_login']	= '';
			$data['loginOnlyOTP']	= false;

			unset($this->session->data['sap_sms']['otp_verfied']);

			if ($this->socia_llogin->isExtensionInstalled('sap_sms')) {
				if ($this->config->get('sap_sms_status') && $this->config->get('sap_sms_otpstatus')) {
					if ($this->config->get('sap_sms_loginbtnstatus')) {
						$data['sap_otp_login'] = $this->load->controller('extension/module/sap_sms', ['page' => 'loginpopup']);

						if (isset($setting['sociallogin_login_only_otp']) && $setting['sociallogin_login_only_otp']) {
							$data['loginOnlyOTP'] = true;
						}
					} else if ($this->config->get('sap_sms_registerbtnstatus')) {
						$this->load->controller('extension/module/sap_sms/otpLoadScript');
					}
				}
			}

			return $this->socia_llogin->renderView($this->path, $data);
		}
	}

	public function getSocialProvider()
	{
		if ($this->providersCache !== null) {
			return $this->providersCache;
		}

		$providers	= [];
		$setting	= $this->setting;

		foreach ($this->socials as $key) {
			$social	= 'sociallogin_' . strtolower($key);
			$config	= [];

			if (isset($setting[$social . 'status']) && $setting[$social . 'status'] > 0) {
				if (isset($setting[$social . 'appsecret']) && $setting[$social . 'appsecret']) {
					$config['secret'] = $setting[$social . 'appsecret'];
				}
				if (isset($setting[$social . 'appid']) && $setting[$social . 'appid']) {
					$config['id'] = $setting[$social . 'appid'];
				}
				if (isset($setting[$social . 'appkey']) && $setting[$social . 'appkey']) {
					$config['key'] = $setting[$social . 'appkey'];
				}

				if ($key == 'Apple') {
					if (isset($setting[$social . 'teamid']) && $setting[$social . 'teamid']) {
						$config['team_id'] = $setting[$social . 'teamid'];
					}
					if (isset($setting[$social . 'id']) && $setting[$social . 'id']) {
						$config['id'] = $setting[$social . 'id'];
					}
					if (isset($setting[$social . 'keyid']) && $setting[$social . 'keyid']) {
						$config['key_id'] = $setting[$social . 'keyid'];
					}
					if (isset($setting[$social . 'keyp8']) && $setting[$social . 'keyp8']) {
						$config['key_file'] = $setting[$social . 'keyp8'];
					}
				}

				$providers[$key] = [
					'enabled'	=> true,
					'keys'		=> $config,
				];

				if ($key == 'Facebook') {
					$providers['Facebook'] += [
						'trustForwarded' => false,
					];
				}

				if ($key == 'Apple') {
					$providers['Apple'] += [
						'verifyTokenSignature' => false,
					];
				}
			}
		}

		$this->providersCache = [
			'callback'		=> $this->url->link('', '', true) . rawurlencode($this->path . '/callback'),
			'providers'		=> $providers,
			'curl_options'	=> [CURLOPT_SSL_VERIFYPEER => false],
		];

		return $this->providersCache;
	}

	protected function initializeHybridauth()
	{
		static $hybridauth = null;

		if ($hybridauth !== null) {
			return $hybridauth;
		}

		if (!class_exists('Hybridauth')) {
			require_once DIR_SYSTEM . 'library/social/vendor/autoload.php';
		}

		$hybridauth = new Hybridauth\Hybridauth($this->getSocialProvider());
		return $hybridauth;
	}

	public function oauth()
	{
		try {
			$hybridauth = $this->initializeHybridauth();

			if (!($providers = $hybridauth->getProviders())) {
				$this->logError('Hybridauth Error: Providers not found');
				return;
			}

			$storage = new Hybridauth\Storage\Session();

			$providerParam	= isset($_GET['provider']) ? $_GET['provider'] : null;
			$state			= isset($_GET['state']) ? $_GET['state'] : null;

			if ($storedProvider = $storage->get('provider')) {
				$hybridauth->disconnectAllAdapters($storedProvider);
				$storage->clear();
			}

			if ($providerParam && in_array($providerParam, $providers)) {
				$storage->set('provider', $providerParam);

				if ($state) {
					$storage->set('state', $state);
				}
			} elseif ($providerParam) {
				$this->logError('Hybridauth Error: Provider ' . $providerParam . ' not found or not enabled in $config');
				return;
			}

			if (!empty($this->session->data['provider'])) {
				$hybridauth->disconnectAllAdapters($this->session->data['provider']);
				unset($this->session->data['provider']);
			} elseif ($hybridauth->getConnectedProviders()) {
				$hybridauth->disconnectAllAdapters();
			}

			if (($provider = $storage->get('provider'))) {
				$hybridauth->authenticate($provider);
			}
		} catch (Hybridauth\Exception\Exception $e) {
			$this->logError('HybridAuth Error: ' . $e->getMessage());
		}
	}

	public function callback()
	{
		try {
			$userAgent = isset($this->request->server['HTTP_USER_AGENT']) ? $this->request->server['HTTP_USER_AGENT'] : '';
			$isMobile = (bool) preg_match('/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i', $userAgent);
		
			$hybridauth	= $this->initializeHybridauth();
			$storage	= new Hybridauth\Storage\Session();

			if ($provider = $storage->get('provider')) {
				$sessionProvider = isset($this->session->data['provider']) ? $this->session->data['provider'] : '';
				if (!$sessionProvider || $sessionProvider !== $provider) {
					$this->session->data['provider'] = $provider;
				}

				$adapter = $hybridauth->getAdapter($provider);
				$adapter->authenticate();

				$userProfile = json_encode($adapter->getUserProfile());
				$this->session->data['userProfile'] = json_decode($userProfile, true);

				$storage->set('provider', null);

				if ($isMobile && $provider === 'Facebook') {
					$state = $storage->get('state');
					$redirectUrl = $state ? urldecode($state) : $this->url->link('account/account');
					$storage->set('state', null);

					if (strpos($redirectUrl, '#_=_') !== false) {
						$redirectUrl = str_replace('#_=_', '', $redirectUrl);
					}

					$this->response->redirect($redirectUrl);
				}

				$view = $this->socia_llogin->renderView($this->path . '/auth');
				$this->response->setOutput($view);
			}
		} catch (Hybridauth\Exception\Exception $e) {
			$this->reset();

			if (strpos($e->getMessage(), 'user_cancelled_login') !== false || strpos($e->getMessage(), 'access_denied') !== false) {
				echo "<script>window.close();</script>";
				exit;
			} else {
				$this->logError('HybridAuth Error: ' . $e->getMessage());
			}
		}
	}

	public function customerLogoutAfter()
	{
		if (isset($this->session->data['provider'])) {
			if (!class_exists('Hybridauth')) {
				require_once DIR_SYSTEM . 'library/social/vendor/autoload.php';
			}
			(new Hybridauth\Storage\Session())->clear();
			unset($this->session->data['provider']);
		}
	}

	public function reset()
	{
		unset(
			$this->session->data['provider'],
			$this->session->data['userProfile']
		);
	}

	public function generateAdditionalForm($userProfile)
	{
		$data = [
			'photoURL'					=> 'image/catalog/sociallogin/blankuser.jpg',
			'text_social_additional'	=> $this->language->get('text_social_additional'),
			'button_continue'			=> $this->language->get('button_continue'),
			'provider'					=> $this->setting['provider'],
		];

		if (isset($userProfile['photoURL']) && $userProfile['photoURL'] && $userProfile['photoURL'] != 'blank') {
			$data['photoURL'] = $userProfile['photoURL'];
		}

		$first_name	= '';
		$last_name	= '';

		if (isset($userProfile['displayName'])) {
			$name		= explode(' ', $userProfile['displayName']);
			$first_name	= $name[0];
			$last_name	= isset($name[1]) ? $name[1] : $name[0];
		}

		$userProfile['firstname']	= !empty($userProfile['firstName']) ? $userProfile['firstName'] : $first_name;
		$userProfile['lastname']	= !empty($userProfile['lastName']) ? $userProfile['lastName'] : $last_name;

		$data['name'] = $userProfile['firstname'] . ' ' . $userProfile['lastname'];

		foreach (array_keys($this->config->get('sociallogin_rawfields')) as $key) {
			$fieldValue[$key] = isset($userProfile[$key]) ? $userProfile[$key] : '';
		}

		$this->loadCustomerGroups($data);

		$fieldValue['value_custom_field'] = [];

		$customFields	= $this->{$this->my_model}->getCustomFields();
		$field_data		= $this->socia_llogin->getBuildingFields($this->setting, 'sociallogin_social_fields', $fieldValue);

		foreach ($customFields as $customField) {
			if ($customField['location'] == 'account') {
				$field_data[$customField['custom_field_id']] = $customField;
				$field_data[$customField['custom_field_id']]['custom_field'] = true;
				$field_data[$customField['custom_field_id']]['enabled'] = true;
			}
		}

		$this->socia_llogin->loadScriptAndStyle($field_data, false);

		$data['fields']				= $this->socia_llogin->sortFields($field_data, $data['customer_groups']);
		$data['text_agree']			= !empty($field_data['agree']['enabled']) ? $this->getAgreements() : '';
		$data['display_newsletter']	= $field_data['newsletter']['enabled'];

		$this->processSLSettings($data, $this->setting);

		return $this->socia_llogin->renderView($this->path . '/form', $data);
	}

	private function processSLSettings(&$data, $setting)
	{
		$data['sociallogin_show_country_code'] = false;

		if (isset($setting['sociallogin_show_country_code']) && $setting['sociallogin_show_country_code']) {
			$data['sociallogin_show_country_code']	= true;
			$data['config_tel_input']				= json_encode($this->socia_llogin->configInitTelInput());
		}

		$data['language'] = isset($this->session->data['language']) && strlen($this->session->data['language']) > 0 && strlen($this->session->data['language']) < 6
			? $this->session->data['language']
			: $this->config->get('config_language');

		$data['entry_newsletter']	= sprintf($this->language->get('entry_newsletter_checkout'), $this->config->get('config_name'));
		$data['custom_css']			= isset($setting['sociallogin_css']) ? html_entity_decode($setting['sociallogin_css'], ENT_QUOTES, 'UTF-8') : '';
	}

	private function loadCustomerGroups(&$data)
	{
		$data['customer_groups'] = [];

		if (is_array($this->config->get('config_customer_group_display'))) {
			$this->load->model('account/customer_group');
			$customerGroups = $this->model_account_customer_group->getCustomerGroups();

			foreach ($customerGroups as $customerGroup) {
				if (in_array($customerGroup['customer_group_id'], $this->config->get('config_customer_group_display'))) {
					$data['customer_groups'][] = $customerGroup;
				}
			}
		}

		$data['customer_group_id'] = (int)$this->config->get('config_customer_group_id');
	}

	public function validate()
	{
		if ($this->customer->isLogged()) {
			return;
		}

		$this->language->load('account/register');

		$this->load->model('account/customer');
		$this->load->model('account/customer_group');

		$json = [];

		if (!isset($this->request->post['customer_group_id'])) {
			$this->request->post['customer_group_id'] = (int)$this->config->get('config_customer_group_id');
		}

		if (isset($this->request->post['telephone'])) {
			$this->request->post['telephone'] = preg_replace('~\D+~','', $this->request->post['telephone']);
		}

		if ($this->socia_llogin->isExtensionInstalled('sap_sms')) {
			if ($this->{$this->my_model}->getTotalCustomersByTelephone($this->request->post['telephone'])) {
				$json['error']['telephone'] = $this->language->get('error_exists_tel');
			}
		}

		$field_data = $this->socia_llogin->getBuildingFields($this->setting, 'sociallogin_social_fields');

		foreach ($field_data as $key => $field) {
			if ($field['enabled'] && $field['required'] && $field['type'] != 'checkbox') {
				$field_error = $this->socia_llogin->validateFields($key, $field, $this->request->post[$key]);
				if($field_error){
					$json['error'][$key] = $field_error;
				}
			}
		}

		if ($this->model_account_customer->getTotalCustomersByEmail($this->request->post['email'])) {
			if (in_array($this->request->post['provider'], ['Telegram', 'Reddit'])) {
				if (!$this->customer->login($this->request->post['email'], $this->request->post['password'])) {
					$json['error']['email'] = $json['error']['password'] = $this->language->get('error_login');
				} else {
					$json['redirect'] = $this->socia_llogin->getCurrentUrl(1, 1);

					$this->trackingUser($this->customer->getId());
					$this->trackingLogin($this->request->post['email']);
				}
			} else {
				$json['error']['email'] = $this->language->get('error_exists');
			}
		}

		if (isset($this->request->post['customer_group_id']) && is_array($this->config->get('config_customer_group_display')) && in_array($this->request->post['customer_group_id'], $this->config->get('config_customer_group_display'))) {
			$customerGroupId = $this->request->post['customer_group_id'];
		} else {
			$customerGroupId = (int)$this->config->get('config_customer_group_id');
		}

		$customFields = $this->{$this->my_model}->getCustomFields($customerGroupId);

		foreach ($customFields as $customField) {
			if ($customField['location'] == 'account') {
				$customFieldPost = isset($this->request->post['custom_field'][$customField['custom_field_id']]) ? $this->request->post['custom_field'][$customField['custom_field_id']] : null;
				$customFieldError = $this->socia_llogin->validateCustomField($customField, $customFieldPost);
				if ($customFieldError) {
					$json['error']['custom_field' . $customField['custom_field_id']] = $customFieldError;
				}
			}
		}

		if (!$json) {
			$json['redirect'] = $this->addCustomer($customerGroupId);
		}

		$this->sendJsonResponse($json);
	}

	public function addCustomer($customerGroupId, $userProfile = [])
	{
		$this->load->model('account/customer');

		if ($userProfile) {
			$first_name	= '';
			$last_name	= '';

			if (isset($userProfile['displayName'])) {
				$name		= explode(' ', $userProfile['displayName']);
				$first_name	= $name[0];
				$last_name	= isset($name[1]) ? $name[1] : $name[0];
			}

			$userProfile['firstname']	= isset($userProfile['firstname']) ? $userProfile['firstname'] : $first_name;
			$userProfile['lastname']	= isset($userProfile['lastname']) ? $userProfile['lastname'] : $last_name;

			$field_data = $userProfile;
		} else {
			$field_data = $this->request->post;
		}

		if (!isset($field_data['password'])) {
			$field_data['password'] = $this->{$this->my_model}->getRandomPassword();
		}

		if (isset($field_data['telephone'])) {
			$field_data['telephone'] = preg_replace('~\D+~', '', $field_data['telephone']);
		}

		$position = $this->socia_llogin->getAddressGeoIP();

		foreach ($position as $key => $value) {
			$field_data[$key] = $value;
		}

		return $this->CustomerSave($field_data, $customerGroupId);
	}

	public function DisplayOneTap()
	{
		if ($this->customer->isLogged()) {
			return;
		}

		if (!$this->config->get('sociallogin_status') || !$this->config->get('sociallogin_googlestatus') || !$this->config->get('sociallogin_gotw_status')) {
			return;
		}

		$data = [
			'isGoogleAutoSignInAvailable'	=> false,
			'clientId'						=> 0
		];

		$positions = [
			1 => 'bottom:5px;right:5px;',
			2 => 'top:135px;right:5px;',
			3 => 'top:5px;left:5px;',
			4 => 'bottom:5px;left:5px;'
		];

		$position = (int)$this->config->get('sociallogin_onetapposition');
		$data['position']			= isset($positions[$position]) ? $positions[$position] : $positions[1];
		$data['cancelOnTapOutside']	= ($this->config->get('sociallogin_onetapcanceloutside')) ? 'true' : 'false';
		$activatedPages				= $this->config->get('sociallogin_onetapdisplay');
		$requestUri					= $this->request->server['REQUEST_URI'];
		$languageCode				= $this->language->get('code');

		if ((($requestUri == '/' || $requestUri == '/' . mb_substr($languageCode, 0, strrpos($languageCode, '-')) . '/' || $requestUri == '/' . $languageCode . '/') && ($activatedPages === 'home')) || ($activatedPages === 'all')) {
			$data['isGoogleAutoSignInAvailable'] = true;
		}

		$clientId = $this->config->get('sociallogin_googleappid');
		$clientSecret = $this->config->get('sociallogin_googleappsecret');

		if ($clientId && $clientSecret) {
			$data['clientId'] = $this->config->get('sociallogin_googleappid');
		}

		$data['SocialLoginUrl']		= $this->url->link($this->path . '/googleautosignin', '', true);
		$data['AutoSigninSilently']	= ($this->config->get('sociallogin_onetapautosignin')) ? 'true' : 'false';

		return $this->socia_llogin->renderView($this->path . '/onetap', $data);
	}

	public function googleautosignin()
	{
		if (!isset($this->request->post['credential'])) {
			$this->response->redirect($this->url->link('error/not_found', '', true));
		}

		$credential	= trim($this->request->post['credential']);
		$profile	= $this->socia_llogin->oneTapDecode($credential);

		if (!$profile) {
			$this->logError('oneTap - ' . $this->language->get('error_access_token'));
			return;
		}

		$userProfile = [
			'identifier'	=> $profile['sub'],
			'email'			=> $profile['email'],
			'displayName'	=> $profile['name'],
			'firstname'		=> isset($profile['given_name']) ? $profile['given_name'] : '',
			'lastname'		=> isset($profile['family_name']) ? $profile['family_name'] : '',
			'photoURL'		=> isset($profile['picture']) ? $profile['picture'] : ''
		];

		$this->setting['provider'] = $this->session->data['provider'] = 'Google';
		$this->session->data['userProfile'] = $userProfile;

		$this->load->model('account/customer');

		$json = [];

		if (!$this->model_account_customer->getTotalCustomersByEmail($userProfile['email'])) {
			$json['redirect'] = $this->addCustomer((int)$this->config->get('config_customer_group_id'), $userProfile);
		} else {
			$this->handleExistingCustomer($userProfile['email']);
			$json['redirect'] = $this->socia_llogin->getCurrentUrl();
		}

		$this->sendJsonResponse($json);
	}

	public function validate_sociallogin()
	{
		if (isset($this->request->server['HTTP_X_REQUESTED_WITH']) && !empty($this->request->server['HTTP_X_REQUESTED_WITH']) && strtolower($this->request->server['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
			$json		= [];
			$redirect	= $this->socia_llogin->getCurrentUrl();

			if ($this->customer->isLogged()) {
				$json['redirect'] = $redirect;
			} else {
				$this->load->model('account/customer');

				$accountType = $this->session->data['account'] = $this->request->post['account'];

				if ($accountType == 'login') {
					$email = isset($this->request->post['email']) ? $this->request->post['email'] : '';
					$password = isset($this->request->post['password']) ? $this->request->post['password'] : '';

					$login_info = $this->model_account_customer->getLoginAttempts($email);

					if ($login_info && ($login_info['total'] >= $this->config->get('config_login_attempts')) && strtotime('-1 hour') < strtotime($login_info['date_modified'])) {
						$json['error']['warning'] = $this->language->get('error_attempts');
					}

					if ((utf8_strlen($email) < 1) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
						$json['error']['email'] = $this->language->get('error_email');
					} else if (utf8_strlen($password) < 1) {
						$json['error']['password'] = $this->language->get('error_password');
					}

					$customer_info = $this->model_account_customer->getCustomerByEmail($email);

					if ($customer_info) {
						$approved_key = $this->isVersion3Plus ? 'status' : 'approved';

						if (!$customer_info[$approved_key]) {
							$json['error']['warning'] = $this->language->get('error_approved');
						}
					}

					if (!isset($json['error'])) {
						if (!$this->customer->login($email, $password)) {
							$json['error']['email'] = $json['error']['password'] = $this->language->get('error_login');
							$this->model_account_customer->addLoginAttempt($email);
						} else {
							$this->model_account_customer->deleteLoginAttempts($email);
						}
					}

					if (!$json) {
						$this->LoginCustomer();
						$json['redirect'] = $redirect;
					}
				} else if ($accountType == 'forgot_password') {
					$email = isset($this->request->post['email']) ? $this->request->post['email'] : '';

					if ((utf8_strlen($email) < 1) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
						$json['error']['email'] = $this->language->get('error_email');
					} 

					if (!isset($json['error'])) {
						if (!$this->model_account_customer->getTotalCustomersByEmail($email)) {
							$json['error']['email'] = $this->language->get('error_email_not_found');
						}
					}

					if (!$json) {
						$code = token(40);

						$this->model_account_customer->editCode($email, $code);

						if ( version_compare( VERSION, '3', '<' ) ) {
							$this->load->language('mail/forgotten');

							$configName = html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8');

							$subject = sprintf($this->language->get('text_subject'), $configName);

							$message  = sprintf($this->language->get('text_greeting'), $configName) . "\n\n";
							$message .= $this->language->get('text_change') . "\n\n";
							$message .= $this->url->link('account/reset', 'code=' . $code, true) . "\n\n";
							$message .= sprintf($this->language->get('text_ip'), $this->request->server['REMOTE_ADDR']) . "\n\n";

							$mail = new Mail();
							$mail->protocol = $this->config->get('config_mail_protocol');
							$mail->parameter = $this->config->get('config_mail_parameter');
							$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
							$mail->smtp_username = $this->config->get('config_mail_smtp_username');
							$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
							$mail->smtp_port = $this->config->get('config_mail_smtp_port');
							$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

							$mail->setTo($email);
							$mail->setFrom($this->config->get('config_email'));
							$mail->setSender($configName);
							$mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
							$mail->setText(html_entity_decode($message, ENT_QUOTES, 'UTF-8'));
							$mail->send();
						}

						if ($this->config->get('config_customer_activity')) {
							$customer_info = $this->model_account_customer->getCustomerByEmail($email);
							if ($customer_info) {
								$this->load->model('account/activity');

								$activity_data = [
									'customer_id'	=> $customer_info['customer_id'],
									'name'			=> $customer_info['firstname'] . ' ' . $customer_info['lastname']
								];

								$this->model_account_activity->addActivity('forgotten', $activity_data);
							}
						}
					}
				} else {
					$field_data = $this->socia_llogin->getBuildingFields($this->setting, 'sociallogin_register_fields');

					if (isset($this->request->post['telephone'])) {
						$this->request->post['telephone'] = preg_replace('~\D+~','', $this->request->post['telephone']);
					}

					if ($this->socia_llogin->isExtensionInstalled('sap_sms')) {
						if ($this->{$this->my_model}->getTotalCustomersByTelephone($this->request->post['telephone'])) {
							$json['error']['telephone'] = $this->language->get('error_exists_tel');
						}
					}

					if (!isset($this->request->post['customer_group_id'])) {
						$this->request->post['customer_group_id'] = (int)$this->config->get('config_customer_group_id');
					}

					foreach ($field_data as $key => $field) {
						if ($field['enabled'] && $field['required']) {
							if (in_array($field['type'], ['text','date','textarea','datetime','time','email','tel','select','radio'])){
								$field_error = $this->socia_llogin->validateFields($key, $field, $this->request->post[$key]);
								if ($field_error) {
									$json['error'][$key] = $field_error;
								}
							} 

							if ($accountType == 'registration' && in_array($field['type'], ['password'])) {
								$field_error = $this->socia_llogin->validateFields($key, $field, $this->request->post[$key]);
								if ($field_error) {
									$json['error'][$key] = $field_error;
								}
							}
						}
					}

					$this->load->model('account/customer_group');

					if (isset($this->request->post['customer_group_id']) && is_array($this->config->get('config_customer_group_display')) && in_array($this->request->post['customer_group_id'], $this->config->get('config_customer_group_display'))) {
						$customer_group_id = $this->request->post['customer_group_id'];
					} else {
						$customer_group_id = (int)$this->config->get('config_customer_group_id');
					}

					$customFields = $this->{$this->my_model}->getCustomFields($customer_group_id);

					foreach ($customFields as $customField) {
						if ($customField['location'] == 'account') {
							$custom_field_post = isset($this->request->post['custom_field'][$customField['custom_field_id']]) ? $this->request->post['custom_field'][$customField['custom_field_id']] : null;
							$custom_field_error = $this->socia_llogin->validateCustomField($customField, $custom_field_post);
							if($custom_field_error){
								$json['error']['custom_field' . $customField['custom_field_id']] = $custom_field_error;
							}
						}
					}

					if ($this->config->get('captcha_'.$this->config->get('config_captcha') . '_status')) {
						$register_captcha = in_array('register', (array)$this->config->get('config_captcha_page')) ? true : false;

						if ($accountType == 'registration' && $register_captcha) {
							$captcha = $this->load->controller($this->path . $this->config->get('config_captcha').'_captcha/validate');
							if ($captcha) {
								$json['error']['captcha'] = $captcha;
							}
						}
					}

					if ($this->isVersion3Plus) {
						if ($this->config->get('captcha_'.$this->config->get('config_captcha') . '_status')) {
							$register_captcha = in_array('register', (array)$this->config->get('config_captcha_page')) ? true : false;

							if ($accountType == 'registration' && $register_captcha) {
								$captcha = $this->load->controller($this->path . '/' . $this->config->get('config_captcha').'_captcha/validate');
								if ($captcha) {
									$json['error']['captcha'] = $captcha;
								}
							}
						}
					} else {
						if ($this->config->get($this->config->get('config_captcha') . '_status')) {
							$register_captcha = in_array('register', (array)$this->config->get('config_captcha_page')) ? true : false;

							if ($accountType == 'registration' && $register_captcha) {
								$captcha = $this->load->controller($this->path . '/' . $this->config->get('config_captcha').'/validate');
								if ($captcha) {
									$json['error']['captcha'] = $captcha;
								}
							}
						}
					}

					$this->session->data['newsletter'] = isset($this->request->post['newsletter']) ? true : false;

					if ($this->model_account_customer->getTotalCustomersByEmail($this->request->post['email'])) {
						$json['error']['email'] = $this->language->get('error_exists');
					}

					if (!$json) {
						$position = $this->socia_llogin->getAddressGeoIP();

						foreach ($position as $key => $value) {
							$this->request->post[$key] = $value;
						}

						if ($this->socia_llogin->isExtensionInstalled('sap_sms')) {
							if ($this->config->get('sap_sms_status') && $this->config->get('sap_sms_otpstatus')) {
								if ($this->config->get('sap_sms_registerbtnstatus')) {
									$json = $this->load->controller('extension/module/sap_sms/viewOTP', ['page' => 'registerpopup']);
									if ($json) {
										$this->sendJsonResponse($json);
										return ;
									}
								}
							}
						}

						unset($this->session->data['sap_sms']['otp_verfied']);

						$json['redirect'] = $this->CustomerSave($this->request->post, $customer_group_id);
					}
				}
			}

			$this->sendJsonResponse($json);
		} else {
			$this->response->redirect($this->url->link('error/not_found', '', true));
		}
	}

	private function handleExistingCustomer($email)
	{
		if (!$this->customer->login($email, '', true)) {
			$this->model_account_customer->addLoginAttempt($email);
		} else {
			$this->model_account_customer->deleteLoginAttempts($email);
		}

		$this->LoginCustomer();

		if (!$this->{$this->my_model}->getUserByEmail($email, $this->session->data['provider'])) {
			$this->trackingUser($this->customer->getId());
		}

		$this->trackingLogin($email);
	}

	private function trackingLogin($email)
	{
		if (isset($this->session->data['provider']) && $this->session->data['provider']) {
			if (($userId = $this->{$this->my_model}->getUserByEmail($email, $this->session->data['provider'])) && ($user = $this->{$this->my_model}->getUser($userId))) {
				$social		= $this->session->data['provider'];
				$login_time	= date('Y-m-d H:i:s');
				$user['last_login_type'] = $social;
				$user['last_login_time'] = $login_time;

				if ($this->{$this->my_model}->update($user, '`id_user` = ' . (int)$user['id_user'])) {
					$connect['id_user']			= $user['id_user'];
					$connect['last_login_type']	= $social;
					$connect['last_login_time']	= $login_time;

					$this->{$this->my_model}->save($connect, 'connect');
				}
			}
		}

		unset($this->session->data['provider']);
	}

	private function trackingUser($customer_id)
	{
		if (!empty($this->session->data['userProfile']) && $customer_id && (isset($this->session->data['provider']) && $this->session->data['provider'])) {
			$profile = $this->session->data['userProfile'];

			$user = $this->{$this->my_model}->getUser((($itemId = (int)$this->{$this->my_model}->getUserByEmail($profile['email'], $this->session->data['provider'])) ? $itemId : null));

			$user['id_customer'] = (int)$customer_id;

			if (!empty($profile['identifier'])) {
				$user['identifier'] = $profile['identifier'];
			}

			if (!empty($profile['photoURL'])) {
				$user['profile_img'] = trim($profile['photoURL']);
			}

			if (!empty($profile['profileURL'])) {
				$user['profile_url'] = trim($profile['profileURL']);
			}

			$user['network'] = $this->session->data['provider'];
			$user['id_shop'] = (int)$this->config->get('config_store_id');

			$this->{$this->my_model}->save($user);
		}

		unset($this->session->data['userProfile']);
	}

	private function LoginCustomer()
	{
		$this->clearSessionData();

		$this->load->model('account/address');

		$address_info = $this->model_account_address->getAddress($this->customer->getAddressId());
		if ($address_info) {
			if ($this->config->get('config_tax_customer') == 'payment') {
				$this->session->data['payment_address'] = $this->model_account_address->getAddress($this->customer->getAddressId());
			}

			if ($this->config->get('config_tax_customer') == 'shipping') {
				$this->session->data['shipping_address'] = $this->model_account_address->getAddress($this->customer->getAddressId());
			}
		} else {
			unset($this->session->data['payment_address']);
			unset($this->session->data['shipping_address']);
		}

		if (isset($this->session->data['wishlist']) && is_array($this->session->data['wishlist'])) {
			$this->load->model('account/wishlist');

			foreach ($this->session->data['wishlist'] as $key => $product_id) {
				$this->model_account_wishlist->addWishlist($product_id);

				unset($this->session->data['wishlist'][$key]);
			}
		}

		if ($this->config->get('config_customer_activity')) {
			$this->load->model('account/activity');

			$activity_data = [
				'customer_id' => $this->customer->getId(),
				'name' => $this->customer->getFirstName() . ' ' . $this->customer->getLastName() 
			];

			$this->model_account_activity->addActivity('login', $activity_data);
		}
	}

	private function CustomerSave($field_data, $customerGroupId)
	{
		$this->clearSessionData();

		$postData = $this->socia_llogin->getRegisterPostData($field_data);
		$customer_id = $this->model_account_customer->addCustomer($postData);

		if ($this->isVersion3Plus && (isset($this->setting['sociallogin_geoip']) && $this->setting['sociallogin_geoip'])) {
		//if ($this->isVersion3Plus) {
			$this->load->model('account/address');
			$this->model_account_address->addAddress($customer_id, $postData);
		}

		if (isset($this->setting['sociallogin_show_country_code']) && $this->setting['sociallogin_show_country_code'] && isset($field_data['country_code'])) {
			$this->{$this->my_model}->editTelephone($customer_id, $field_data['telephone'], $field_data['country_code'], $this->setting);
		}

		$this->model_account_customer->deleteLoginAttempts($field_data['email']);

		$customerGroup = $this->model_account_customer_group->getCustomerGroup($customerGroupId);
		if ($customerGroup && !$customerGroup['approval']) {
			$this->customer->login($field_data['email'], html_entity_decode($field_data['password'], ENT_QUOTES, 'UTF-8'));
			if ((isset($this->setting['sociallogin_additional']) && $this->setting['sociallogin_additional']) || (isset($field_data['provider']) && in_array($field_data['provider'], ['Telegram', 'Reddit']))) {
				$redirect = $this->socia_llogin->getCurrentUrl(1, 1);
			} else {
				$redirect = $this->socia_llogin->getCurrentUrl();
			}
		} else {
			$redirect = $this->url->link('account/success');
		}

		if (version_compare(VERSION, '3.0.0', '<') && $this->config->get('config_customer_activity')) {
			$this->load->model('account/activity');

			if (isset($field_data['firstname']) || isset($field_data['lastname'])) {
				$name = (isset($field_data['firstname']) ? $field_data['firstname'] . ' ' : '') . (isset($field_data['lastname']) ? $field_data['lastname'] : '');
			} else {
				$name = $field_data['email'];
			}

			$activity_data = [
				'customer_id'	=> $customer_id,
				'name'			=> $name 
			];

			$this->model_account_activity->addActivity('register', $activity_data);
		}

		$this->trackingUser($customer_id);
		$this->trackingLogin($field_data['email']);

		return $redirect;
	}

	private function clearSessionData()
	{
		$keysToUnset = ['guest', 'payment_address', 'shipping_address', 'agree'];
		foreach ($keysToUnset as $key) {
			if (isset($this->session->data[$key])) {
				unset($this->session->data[$key]);
			}
		}
	}

	public function sl_shortcode()
	{
		if ($this->customer->isLogged()) {
			return;
		}

		$setting = $this->setting;

		if (!isset($setting['sociallogin_status']) || !$setting['sociallogin_status']) {
			return;
		}

		$what_page_active = $this->getActivePage();

		if (empty($what_page_active)) {
			return;
		}

		$settingKey = 'sociallogin_' . $what_page_active;

		if (!isset($setting[$settingKey]) || !$setting[$settingKey]) {
			return;
		}

		$data['popup'] = false;

		if (!isset($setting['sociallogin_popuplogin'])) {
			$jsDirectory = 'catalog/view/javascript/sociallogin/';

			$this->document->addStyle($jsDirectory . 'css/sociallogin.css');
			$this->document->addScript($jsDirectory . 'sociallogin.js');

			if (isset($this->session->data['sociallogin']['login_modal']) && $this->session->data['sociallogin']['login_modal']) {
				unset($this->session->data['sociallogin']['login_modal']);
				$data = [
					'popup'		=> true,
					'style'		=> $jsDirectory . 'css/sociallogin.css',
					'script'	=> $jsDirectory . 'sociallogin.js',
				];
			}
		}

		$data['setting']	= $setting;
		$data['position']	= $what_page_active;

		if ($setting['sociallogin_button'][$what_page_active] != 'icon') {
			$this->load->model('tool/image');
		}

		$languageId = $this->config->get('config_language_id');
		$data['sociallogin_titlelogin'][$what_page_active] = isset($setting['sociallogin_titlelogin'][$what_page_active][$languageId])
			? $setting['sociallogin_titlelogin'][$what_page_active][$languageId]
			: '';

		foreach ($this->socials as $key) {
			$provider = mb_strtolower($key);

			$data['providers'][$what_page_active][] = $key;
			$data[$provider . 'status'][$what_page_active] = !empty($setting['sociallogin_' . $provider . 'status']) && !empty($setting['sociallogin_to_use_' . $what_page_active][$provider]);
			$data['sociallogin_' . $provider . 'title'][$what_page_active]	= isset($setting['sociallogin_' . $provider . 'title'][$what_page_active][$languageId])
				? $setting['sociallogin_' . $provider . 'title'][$what_page_active][$languageId]
				: '';

			if ($setting['sociallogin_button'][$what_page_active] != 'icon') {
				$data['sociallogin_' . $provider . 'image'][$what_page_active] = $this->getProviderImage($setting, $provider, $what_page_active);
			}
		}

		return $this->socia_llogin->renderView($this->path . '/sl_shortcode', $data);
	}

	public function slNetworksOneAccount()
	{
		if (!$this->customer->isLogged()) {
			return;
		}

		$setting = $this->setting;

		if (!isset($setting['sociallogin_status']) || !$setting['sociallogin_status']) {
			return;
		}

		if (!isset($setting['sociallogin_account']) || !$setting['sociallogin_account']) {
			return;
		}

		$jsDirectory = 'catalog/view/javascript/sociallogin/';

		$data = [
			'style'		=> $jsDirectory . 'css/sociallogin.css',
			'script'	=> $jsDirectory . 'sociallogin.js',
		];

		$this->load->model('tool/image');

		$languageId = $this->config->get('config_language_id');

		$conns = [];
		if (($connects = $this->{$this->my_model}->getUserConnects($this->customer->getId()))) {
			foreach ($connects as $connect)
				$conns[$connect['last_login_type']] = $connect;
		}

		$activeSocials = [];

		foreach ($this->socials as $key) {
			$provider = mb_strtolower($key);

			$data['providers'][] = $key;
			$data[$provider . 'status'] = !empty($setting['sociallogin_' . $provider . 'status']) && !empty($setting['sociallogin_to_use_account'][$provider]);

			if ($data[$provider . 'status']) {
				$activeSocials[] = $key;
			}

			$data['sociallogin_' . $provider . 'title']	= isset($setting['sociallogin_' . $provider . 'title']['account'][$languageId])
				? $setting['sociallogin_' . $provider . 'title']['account'][$languageId]
				: '';

			$data['sociallogin_' . $provider . 'image'] = $this->getProviderImage($setting, $provider, 'account');

			if (!(isset($conns[$key]))) {
				$conns[$key] = ['last_login_type' => $key, 'last_login_time' => null];
			}
		}

		$data['connects'] = $conns;

		$count		= count($activeSocials);
		$network	= implode(', ', array_slice($activeSocials, 0, $count - 1)) . ($count > 1 ? $this->language->get('text_or') : '') . end($activeSocials);

		$data['sociallogin_titleacc']	= sprintf($this->language->get('sociallogin_titleacc'), $this->config->get('config_name'), $network);
		$data['cancel_connection']		= $this->language->get('text_cancel_connection');
		$data['link_network']			= $this->language->get('text_link_network');

		return $this->socia_llogin->renderView($this->path . '/social_page', $data);
	}

	public function getActivePage()
	{
		$route = isset($this->request->get['route']) ? $this->request->get['route'] : '';

		$pageMappings = [
			'account/login'				=> 'login',
			'checkout/login'			=> 'checkout',
			'account/register'			=> 'reg',
			'checkout/simplecheckout'	=> 'checkout',
			'account/simpleregister'	=> 'reg'
		];

		$additionalRoutes = [
			'checkout'			=> 'checkout',
			'fastorder'			=> 'checkout',
			'oct_popup_login'	=> 'login'
		];

		if (isset($pageMappings[$route])) {
			return $pageMappings[$route];
		}

		foreach ($additionalRoutes as $additionalRoute => $page) {
			if (strpos($route, $additionalRoute) !== false) {
				return $page;
			}
		}

		if (isset($this->session->data['sociallogin']['login_modal']) && $this->session->data['sociallogin']['login_modal']) {
			return 'login';
		}

		return '';
	}

	private function getProviderImage($setting, $provider, $page)
	{
		$imageKey = 'sociallogin_' . $provider . 'image';
		$image = (isset($setting[$imageKey][$page]) && $setting[$imageKey][$page]) ? $setting[$imageKey][$page] : 'placeholder.png';

		if (strtolower(pathinfo($image, PATHINFO_EXTENSION)) === 'svg') {
			if (strpos($image, DIR_IMAGE) === 0) {
				$image = substr($image, strlen(DIR_IMAGE));
			}
			$base = rtrim($this->request->server['HTTPS'] ? $this->config->get('config_ssl') : $this->config->get('config_url'), '/');
			return $base . '/image/' . ltrim($image, '/');
		}

		return $this->model_tool_image->resize($image, 32, 32);
	}

	public function deleteNetwork()
	{
		$json = [];

		if (!$this->customer->isLogged()) {
			return;
		}

		if (isset($this->request->post['provider'])) {
			$this->{$this->my_model}->getUserRemoveConnects($this->customer->getId(), $this->request->post['provider']);
			$json['success'] = true;
		}

		$this->sendJsonResponse($json);
	}

	public function TelephoneCountryCode()
	{
		if (isset($this->setting['sociallogin_country_code_location']) && $this->setting['sociallogin_country_code_location'] == 'new') {
			$telephone_data	= $this->{$this->my_model}->separateCountryCode();
			$country_code	= $telephone_data['country_code'];
			//if (!$country_code) {
			//	$country_code = $this->{$this->my_model}->getCountryCode($this->customer->getId());
			//}
		} else {
			$country_code = $this->{$this->my_model}->getCountryCode($this->customer->getId());
		}

		if (isset($country_code) && $country_code) {
			setcookie( 'sociallogin_country_code', '1', time() + 2592000, '/', $this->request->server['HTTP_HOST'] );
			return;
		}

		$data = $this->load->language($this->path);

		$field_data	= $this->socia_llogin->getBuildingFields($this->setting, 'sociallogin_register_fields');
		$links		= $this->socia_llogin->getScriptsAndStyles($field_data);

		$data['styles']		= $links['styles'];
		$data['scripts']	= $links['scripts'];

		$telephone_data = $field_data['telephone'];

		$data['tooltip']			= $telephone_data['tooltip'];
		$data['is_mask']			= $telephone_data['is_mask'];
		$data['mask']				= $telephone_data['mask'];
		$data['telephone_title']	= $telephone_data['title'];
		$data['type']				= $telephone_data['type'];
		$data['maximum']			= $telephone_data['maximum'];
		$data['numeric']			= $telephone_data['numeric'];
		$data['telephone']			= $this->customer->getTelephone();
		$data['display_old']		= (isset($this->setting['sociallogin_show_old_phone']) && $this->setting['sociallogin_show_old_phone'] ? true : false);

		$data['sociallogin_show_country_code'] = false;

		if (isset($this->setting['sociallogin_show_country_code']) && $this->setting['sociallogin_show_country_code']) {
			$data['sociallogin_show_country_code']	= true;
			$data['config_tel_input']				= json_encode($this->socia_llogin->configInitTelInput());
		}

		$this->response->setOutput($this->socia_llogin->renderView($this->path . '/countryform', $data));
	}

	public function validateTelephone()
	{
		$json = [];

		$redirect = $this->socia_llogin->getCurrentUrl(1,1);

		if (!$this->customer->isLogged()) {
			$json['redirect'] = $redirect;
		}

		if (!$json) {
			$this->request->post['telephone'] = preg_replace('~\D+~','', $this->request->post['telephone']);

			if ($this->socia_llogin->isExtensionInstalled('sap_sms')) {
				if ($this->{$this->my_model}->getTotalTelephoneAndCountryCode($this->request->post['telephone'])) {
					$json['error']['telephone'] = $this->language->get('error_exists_tel');
				}
			}

			$field_data = $this->socia_llogin->getBuildingFields($this->setting, 'sociallogin_register_fields');
			$field = $field_data['telephone'];
			if ($field['enabled'] && $field['required']) {
				$field_error = $this->socia_llogin->validateFields('telephone', $field, $this->request->post['telephone']);
				if($field_error) {
					$json['error']['telephone'] = $field_error;
				}
			}
		}

		if (!$json) {
			$this->{$this->my_model}->editTelephone($this->customer->getId(), $this->request->post['telephone'], $this->request->post['country_code'], $this->setting);
			$json['redirect'] = $redirect;
		}

		$this->sendJsonResponse($json);
	}

	public function customfield()
	{
		$json = [];

		$customerGroupId = $this->config->get('config_customer_group_id');

		if (isset($this->request->get['customer_group_id']) && is_array($this->config->get('config_customer_group_display')) && in_array($this->request->get['customer_group_id'], $this->config->get('config_customer_group_display'))) {
			$customerGroupId = $this->request->get['customer_group_id'];
		}

		$customFields = $this->{$this->my_model}->getCustomFields($customerGroupId);

		foreach ($customFields as $customField) {
			$json[] = [
				'custom_field_id'	=> $customField['custom_field_id'],
				'required'			=> $customField['required']
			];
		}

		$this->sendJsonResponse($json);
	}

	private function sendJsonResponse($json)
	{
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	private function getAgreements()
	{
		$accountAgreeLink	= $this->getAgreeLink('config_account_id');
		$checkoutAgreeLink	= $this->getAgreeLink('config_checkout_id');

		if ($accountAgreeLink || $checkoutAgreeLink) {
			return sprintf($this->language->get('text_agree'), $accountAgreeLink, $checkoutAgreeLink);
		}

		return null;
	}

	private function getAgreeLink($configKey)
	{
		$agreeLink = '#';
		$configId = $this->config->get($configKey);

		if ($configId) {
			$this->load->model('catalog/information');
			$informationInfo = $this->model_catalog_information->getInformation($configId);

			if ($informationInfo) {
				$agreeLink = $this->url->link('information/information/agree', 'information_id=' . $configId, 'SSL');
			}
		}

		return $agreeLink;
	}

	private function logError($message)
	{
		$this->log->write($message);
	}
}
