<?php

// Heading
$_['heading_title']     = '<span style="background: linear-gradient(to right, #3839f3 , #03b57b); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><a href="https://teragroup.com.ua" target="_blank">TERAGROUP</a></span> HTML Content';

// Text
$_['text_extension']    = 'Extensions';
$_['text_success']      = 'Success: You have modified module!';
$_['text_edit']         = 'Edit module';

// Entry
$_['entry_name']        = 'Module Name';
$_['entry_title']       = 'Heading Title';
$_['entry_description'] = 'Description';
$_['entry_status']      = 'Status';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify module!';
$_['error_name']        = 'Module Name must be between 3 and 64 characters!';