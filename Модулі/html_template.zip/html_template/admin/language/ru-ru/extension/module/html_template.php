<?php

// Heading
$_['heading_title']     = '<span style="background: linear-gradient(to right, #3839f3 , #03b57b); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><a href="https://teragroup.com.ua" target="_blank">TERAGROUP</a></span> Текстовый блок — HTML';

// Text
$_['text_extension']    = 'Расширения';
$_['text_success']      = 'Настройки успешно изменены!';
$_['text_edit']         = 'Настройки модуля';

// Entry
$_['entry_name']        = 'Название модуля';
$_['entry_title']       = 'Заголовок';
$_['entry_description'] = 'Текст';
$_['entry_status']      = 'Статус';

// Error
$_['error_permission']  = 'У Вас нет прав для управления данным модулем!';
$_['error_name']        = 'Название модуля должно содержать от 3 до 64 символов!';