<?php

class ControllerExtensionModuleHtmlTemplate extends Controller {
  public function index($setting) {
    $this->load->language('extension/module/html_template');

    $data['heading_title'] = $this->language->get('heading_title');

    $language_id = $this->config->get('config_language_id');

    if (isset($setting['module_description']) && isset($setting['module_description'][$language_id])) {
      $language_data = $setting['module_description'][$language_id];

      $fields = ['title', 'description'];

      foreach ($fields as $field) {
        $data[$field] = html_entity_decode($language_data[$field], ENT_QUOTES, 'UTF-8');
    }

      return $this->load->view('extension/module/html_template', $data);
    }
  }
}