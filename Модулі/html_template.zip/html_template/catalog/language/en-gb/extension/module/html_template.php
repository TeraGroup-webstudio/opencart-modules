<?php

// Heading
$_['heading_title'] = 'HTML Content';