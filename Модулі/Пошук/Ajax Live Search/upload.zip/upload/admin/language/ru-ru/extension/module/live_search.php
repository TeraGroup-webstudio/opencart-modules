<?php

// Heading Goes here:
$_['heading_title']            = '<strong style="color:#41637d">DEV-OPENCART.COM —</strong> Ajax Live Search <a href="https://dev-opencart.com" target="_blank" title="Dev-opencart.com - Модули и шаблоны для Opencart"><img style="margin-left:15px;height:35px;margin-top:10px;margin-bottom:10px;" src="https://dev-opencart.com/logob.svg" alt="Dev-opencart.com - Модули и шаблоны для Opencart"/></a>';

// Text
$_['text_extension']           = 'Расширения';
$_['text_edit']                = 'Редактировать модуль Ajax Live Search';
$_['text_success']             = 'Успешно: Вы изменили модуль Ajax Live Search!';
$_['text_view_all_results']    = 'Просмотреть все результаты';

// Entry
$_['entry_limit']              = 'Лимит поиска';
$_['entry_width']              = 'Ширина изображения';
$_['entry_height']             = 'Высота изображения';
$_['entry_title_length']       = 'Длина заголовка';
$_['entry_description_length'] = 'Длина описания';
$_['entry_show_image']         = 'Показать изображение';
$_['entry_show_price']         = 'Показать цену';
$_['entry_show_description']   = 'Показать описание';
$_['entry_show_add_button']    = 'Показать кнопку добавления в корзину';
$_['entry_status']             = 'Статус';
$_['entry_view_all_results']   = 'Текст ссылки "Просмотреть все результаты"';
$_['entry_min_length']         = 'Минимальная длина поиска';

// Help
$_['help_length']              = 'Показывать \'...\' когда длина превышает это значение.';
$_['help_view_all_results']    = 'Текст ссылки внизу результатов поиска';

// Error
$_['error_permission']         = 'Внимание: У вас нет прав для изменения модуля Live Search!';
$_['error_limit']              = 'Требуется указать лимит поиска!';
$_['error_width']              = 'Требуется указать ширину изображения!';
$_['error_height']             = 'Требуется указать высоту изображения!';
$_['error_title_length']       = 'Требуется указать длину заголовка!';
$_['error_description_length'] = 'Требуется указать длину описания!';
$_['error_view_all_results']   = 'Требуется указать текст ссылки "Просмотреть все результаты"!';
$_['error_min_length']         = 'Требуется указать минимальную длину поиска!';
