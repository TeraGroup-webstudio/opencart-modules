<?php

// Heading Goes here:
$_['heading_title']            = '<strong style="color:#41637d">DEV-OPENCART.COM —</strong> Ajax Live Search <a href="https://dev-opencart.com" target="_blank" title="Dev-opencart.com - Модулі та шаблони для Opencart"><img style="margin-left:15px;height:35px;margin-top:10px;margin-bottom:10px;" src="https://dev-opencart.com/logob.svg" alt="Dev-opencart.com - Модулі та шаблони для Opencart"/></a>';

// Text
$_['text_extension']           = 'Розширення';
$_['text_edit']                = 'Редагувати модуль Ajax Live Search';
$_['text_success']             = 'Успішно: Ви змінили модуль Ajax Live Search!';
$_['text_view_all_results']    = 'Переглянути всі результати';

// Entry
$_['entry_limit']              = 'Ліміт пошуку';
$_['entry_width']              = 'Ширина зображення';
$_['entry_height']             = 'Висота зображення';
$_['entry_title_length']       = 'Довжина заголовка';
$_['entry_description_length'] = 'Довжина опису';
$_['entry_show_image']         = 'Показати зображення';
$_['entry_show_price']         = 'Показати ціну';
$_['entry_show_description']   = 'Показати опис';
$_['entry_show_add_button']    = 'Показати кнопку додавання в кошик';
$_['entry_status']             = 'Статус';
$_['entry_view_all_results']   = 'Текст посилання "Переглянути всі результати"';
$_['entry_min_length']         = 'Мінімальна довжина пошуку';

// Help
$_['help_length']              = 'Показувати \'...\' коли довжина перевищує це значення.';
$_['help_view_all_results']    = 'Текст посилання внизу результатів пошуку';

// Error
$_['error_permission']         = 'Увага: У вас немає прав для зміни модуля Live Search!';
$_['error_limit']              = 'Потрібно вказати ліміт пошуку!';
$_['error_width']              = 'Потрібно вказати ширину зображення!';
$_['error_height']             = 'Потрібно вказати висоту зображення!';
$_['error_title_length']       = 'Потрібно вказати довжину заголовка!';
$_['error_description_length'] = 'Потрібно вказати довжину опису!';
$_['error_view_all_results']   = 'Потрібно вказати текст посилання "Переглянути всі результати"!';
$_['error_min_length']         = 'Потрібно вказати мінімальну довжину пошуку!';
