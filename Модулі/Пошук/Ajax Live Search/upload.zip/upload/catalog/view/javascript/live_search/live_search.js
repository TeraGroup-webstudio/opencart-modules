var LiveSearchJs = function () {

    var init = function(options) {
        var live_search = {
            selector: "#search input[name='search']",
            text_no_matches: options.text_empty,
            height: '50px'
        }

        var html = '<div class="live-search"><ul></ul><div class="result-text"></div></div>';
        $(live_search.selector).after(html);

        var searchTimer = null;

        function showLiveSearch() {
            var $ls = $('.live-search');
            $ls.css('display', 'block');
            if ($('body').hasClass('mobile')) {
                var rect = $(live_search.selector)[0].getBoundingClientRect();
                $ls.css('top', Math.round(rect.bottom) + 'px');
            }
        }

        function doSearch() {
            var filter_name = $(live_search.selector).val();
            var cat_id = 0;
            var live_search_min_length = options.module_live_search_min_length;

            if (filter_name.length < live_search_min_length) {
                $('.live-search').css('display', 'none');
                return;
            }

            var live_search_href = 'index.php?route=extension/module/live_search&filter_name=';
            var all_search_href = 'index.php?route=product/search&search=';

            if (cat_id > 0) {
                live_search_href = live_search_href + encodeURIComponent(filter_name) + '&cat_id=' + Math.abs(cat_id);
                all_search_href = all_search_href + encodeURIComponent(filter_name) + '&category_id=' + Math.abs(cat_id);
            } else {
                live_search_href = live_search_href + encodeURIComponent(filter_name);
                all_search_href = all_search_href + encodeURIComponent(filter_name);
            }

            var html  = '<li style="text-align: center; padding: 15px 10px;">';
                html += '<img class="loading" src="catalog/view/javascript/live_search/loading.gif" />';
                html += '</li>';
            $('.live-search ul').html(html);
            showLiveSearch();

            $.ajax({
                url: live_search_href,
                dataType: 'json',
                success: function(result) {
                    var products = result.products;
                    $('.live-search ul li').remove();
                    $('.result-text').html('');

                    if (!$.isEmptyObject(products)) {
                        var show_image       = parseInt(options.module_live_search_show_image);
                        var show_price       = parseInt(options.module_live_search_show_price);
                        var show_description = parseInt(options.module_live_search_show_description);
                        var show_add_button  = parseInt(options.module_live_search_show_add_button);

                        $('.result-text').html('<a href="'+all_search_href+'" class="view-all-results">'+options.text_view_all_results+' '+result.total+'</a>');
                        $.each(products, function(index, product) {
                            var html = '<li>';
                            if (show_add_button) {
                                html += '<div class="product-add-cart">';
                                html += '<a href="javascript:;" onclick="cart.add('+product.product_id+', '+product.minimum+');" class="btn btn-primary">';
                                html += '<i class="fa fa-shopping-cart"></i>';
                                html += '</a>';
                                html += '</div>';
                            }
                            html += '<div>';
                            html += '<a href="' + product.url + '" title="' + product.name + '">';
                            if (product.image && show_image) {
                                html += '<div class="product-image"><img alt="' + product.name + '" src="' + product.image + '"></div>';
                            }
                            html += '<div class="product-name">' + product.name;
                            if (show_description) {
                                html += '<p>' + product.extra_info + '</p>';
                            }
                            html += '</div>';
                            if (show_price) {
                                if (product.special) {
                                    html += '<div class="product-price"><span class="price">' + product.special + '</span><span class="special">' + product.price + '</span></div>';
                                } else {
                                    html += '<div class="product-price"><span class="price">' + product.price + '</span></div>';
                                }
                            }
                            html += '</a>';
                            html += '</div>';
                            html += '</li>';
                            $('.live-search ul').append(html);
                        });
                    } else {
                        var html = '';
                        html += '<li style="text-align: center; padding: 15px 10px;">';
                        html += live_search.text_no_matches;
                        html += '</li>';
                        $('.live-search ul').html(html);
                    }

                    showLiveSearch();
                }
            });
        }

        function requestSearch() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(doSearch, 200);
        }

        $(live_search.selector).on('keydown', function(e) {
            if (e.keyCode === 27) {
                $('.live-search').css('display', 'none');
            } else {
                requestSearch();
            }
        });

        $(live_search.selector).on('input', function() {
            requestSearch();
        });

        $(document).bind("mouseup touchend", function(e) {
            var container = $('.live-search');
            if (!container.is(e.target) && container.has(e.target).length === 0) {
                container.hide();
            }
        });
    }

    return {
        init: function(options) {
            init(options);
        }
    };

}();
