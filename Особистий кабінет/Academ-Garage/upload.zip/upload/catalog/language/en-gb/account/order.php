<?php

// Heading
$_['heading_title']          = 'Last Orders';

// Text
$_['text_account']           = 'My Account';
$_['text_order']             = 'Order';
$_['text_order_detail']      = 'Order details';
$_['text_invoice_no']        = 'Invoice number';
$_['text_order_id']          = 'Order';
$_['text_account_order_id']  = 'Order number:';
$_['text_date_added']        = 'Added:';
$_['text_order_from']        = 'From:';
$_['text_product_code']      = 'Product code:';
$_['text_shipping_address']  = 'Shipping address';
$_['text_shipping_method']   = 'Shipping method';
$_['text_payment_address']   = 'Billing address';
$_['text_payment_method']    = 'Payment method';
$_['text_comment']           = 'Order comment';
$_['text_history']           = 'Last Orders';
$_['text_success']           = 'Products from order <a href="%s">%s</a> have been successfully added <a href="%s">to your cart</a>!';
$_['text_empty']             = 'You have not made any orders yet :(';
$_['text_error']             = 'The requested order was not found!';
$_['text_ttn']               = 'TTN';
$_['text_repeat']            = 'Repeat order';
$_['text_summ']              = 'Total:';
$_['text_payment']           = 'Pay for order';

// Tab
$_['tab_current']            = 'Current orders';
$_['tab_done']               = 'Last Orders';

// Button
$_['button_view_text']       = 'More';
$_['btn_enter']              = 'Go';

// Column
$_['column_order_id']        = 'Order ';
$_['column_customer']        = 'Customer';
$_['column_product']         = 'Quantity';
$_['column_product_shot']    = 'Pcs';
$_['column_name']            = 'Product Name';
$_['column_model']           = 'Model';
$_['column_quantity']        = 'Quantity';
$_['column_price']           = 'Price';
$_['column_total']           = 'Total';
$_['column_action']          = 'Action';
$_['column_date_added']      = 'Added';
$_['column_status']          = 'Status';
$_['column_status_shot']     = 'Status';
$_['column_date_added_shot'] = 'Added';
$_['column_comment']         = 'Comment';

// Error
$_['error_reorder']          = '%s currently unavailable for order';