<?php

// Heading
$_['heading_title']          = 'Последние заказы';

// Text
$_['text_account']           = 'Личный Кабинет';
$_['text_order']             = 'Заказ';
$_['text_order_detail']      = 'Детали заказа';
$_['text_invoice_no']        = 'Номер счета';
$_['text_order_id']          = 'Заказ';
$_['text_account_order_id']  = 'Номер заказа:';
$_['text_date_added']        = 'Добавлено:';
$_['text_order_from']        = 'От:';
$_['text_product_code']      = 'Код товара:';
$_['text_shipping_address']  = 'Адрес доставки';
$_['text_shipping_method']   = 'Способ доставки';
$_['text_payment_address']   = 'Платёжный адрес';
$_['text_payment_method']    = 'Способ оплаты';
$_['text_comment']           = 'Комментарий к заказу';
$_['text_history']           = 'Последние заказы';
$_['text_success']           = 'Товары из заказа <a href="%s">%s</a> успешно добавлены <a href="%s">в вашу корзину</a>!';
$_['text_empty']             = 'Вы еще не сделали ни одного заказа :(';
$_['text_error']             = 'Запрошенный заказ не найден!';
$_['text_ttn']               = 'ТТН';
$_['text_repeat']            = 'Повторить заказ';
$_['text_summ']              = 'Всего:';
$_['text_payment']           = 'Оплатить заказ';

// Tab
$_['tab_current']            = 'Текущие заказы';
$_['tab_done']               = 'Последние заказы';

// Button
$_['button_view_text']       = 'Больше';
$_['btn_enter']              = 'Перейти';

// Column
$_['column_order_id']        = 'Заказ ';
$_['column_customer']        = 'Клиент';
$_['column_product']         = 'Количество';
$_['column_product_shot']    = 'Шт';
$_['column_name']            = 'Название товара';
$_['column_model']           = 'Модель';
$_['column_quantity']        = 'Количество';
$_['column_price']           = 'Цена';
$_['column_total']           = 'Сумма';
$_['column_action']          = 'Действие';
$_['column_date_added']      = 'Добавлено';
$_['column_status']          = 'Статус';
$_['column_status_shot']     = 'Статус';
$_['column_date_added_shot'] = 'Добавлено';
$_['column_comment']         = 'Комментарий';

// Error
$_['error_reorder']          = '%s пока не доступны для заказа';