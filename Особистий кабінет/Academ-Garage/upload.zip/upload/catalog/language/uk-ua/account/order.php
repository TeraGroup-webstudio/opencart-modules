<?php

// Heading
$_['heading_title']          = 'Останні замовлення';

// Text
$_['text_account']           = 'Особистий кабінет';
$_['text_order']             = 'Замовлення';
$_['text_order_detail']      = 'Деталі замовлення';
$_['text_invoice_no']        = 'Номер рахунку:';
$_['text_order_id']          = 'Замовлення:';
$_['text_account_order_id']  = 'Номер замовлення:';
$_['text_date_added']        = 'Додано:';
$_['text_order_from']        = 'Від:';
$_['text_product_code']      = 'Код товару:';
$_['text_shipping_address']  = 'Адреса доставки';
$_['text_shipping_method']   = 'Спосіб доставки:';
$_['text_payment_address']   = 'Платіжна адреса';
$_['text_payment_method']    = 'Спосіб оплати:';
$_['text_comment']           = 'Коментар до замовлення';
$_['text_history']           = 'Історія замовлення';
$_['text_success']           = 'Товари із замовлення <a href="%s">%s</a> додані <a href="%s">у кошик</a>';
$_['text_empty']             = 'Ви ще не зробили жодного замовлення :(';
$_['text_error']             = 'Такого замовлення не існує';
$_['text_ttn']               = 'ТТН';
$_['text_repeat']            = 'Повторити замовлення';
$_['text_summ']              = 'Всього:';
$_['text_payment']           = 'Сплатити замовлення';

// Tab
$_['tab_current']            = 'Поточні замовлення';
$_['tab_done']               = 'Останні замовлення';

// Button
$_['button_view_text']       = 'Більше';
$_['btn_enter']              = 'Перейти';

// Column
$_['column_order_id']        = 'Замовлення ';
$_['column_product']         = 'Кількість';
$_['column_customer']        = 'Покупець';
$_['column_name']            = 'Назва товару';
$_['column_model']           = 'Модель';
$_['column_quantity']        = 'Кількість';
$_['column_product_shot']    = 'Шт';
$_['column_price']           = 'Ціна';
$_['column_total']           = 'Сума';
$_['column_action']          = 'Дія';
$_['column_date_added']      = 'Додано';
$_['column_status']          = 'Статус';
$_['column_comment']         = 'Коментар';
$_['column_status_shot']     = 'Статус';
$_['column_date_added_shot'] = 'Додано';

// Error
$_['error_reorder']          = '%s наразі недоступні для замовлення';