<?php
class ControllerAccountOrder extends Controller {

    const CURRENCY_CODE = [
        'UAH' => 980,
        'EUR' => 978,
        'USD' => 840,
    ];

    public function index() {
        $this->document->addStyle('catalog/view/theme/default/stylesheet/breadcrumb.css', 'stylesheet');
        $this->document->addStyle('catalog/view/theme/default/stylesheet/pagination.css', 'stylesheet');
        $this->document->addStyle('catalog/view/theme/default/stylesheet/account.css', 'stylesheet');

        if (!$this->customer->isLogged()) {
            $this->session->data['redirect'] = $this->url->link('account/order', '', true);

            $this->response->redirect($this->url->link('account/login', '', true));
        }

        $this->load->language('account/order');

        $this->document->setTitle($this->language->get('heading_title'));

        $url = '';

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['home'] = $this->url->link('common/home');

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_account'),
            'href' => $this->url->link('account/account', '', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('account/order', $url, true)
        );

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $data['orders'] = array();

        $this->load->model('account/order');
        $this->load->model('catalog/product');
        $this->load->model('tool/image');

        /*foreach ($this->config->get('config_complete_status') as $order_status_id) {
            $implode[] = "'" . (int)$order_status_id . "'";
        }*/
        //AND order_status_id IN(" . implode(",", $implode) . ")

        $order_total = $this->model_account_order->getTotalOrders();

        $results = $this->model_account_order->getOrders(($page - 1) * 10, 10);

        foreach ($results as $result) {
            $product_total = $this->model_account_order->getTotalOrderProductsByOrderId($result['order_id']);
            $voucher_total = $this->model_account_order->getTotalOrderVouchersByOrderId($result['order_id']);

            $order_info = $this->model_account_order->getOrder($result['order_id']);
            $products_list = array();
            $thumbs = array();

            $order_products = $this->model_account_order->getOrderProducts($result['order_id']);

            foreach ($order_products as $order_product) {
                $product_info = $this->model_catalog_product->getProduct($order_product['product_id']);

                if ($product_info && !empty($product_info['image']) && is_file(DIR_IMAGE . $product_info['image'])) {
                    $image = $this->model_tool_image->resize($product_info['image'], 210, 210);
                } else {
                    $image = $this->model_tool_image->resize('no_image.jpg', 210, 210);
                }

                $thumbs[] = array(
                    'image' => $image,
                    'width' => 210,
                    'height' => 210
                );

                $products_list[] = array(
                    'name' => $order_product['name'],
                    'model' => $order_product['model'],
                    'image' => $image,
                    'width' => 210,
                    'height' => 210,
                    'href' => $this->url->link('product/product', 'product_id=' . (int)$order_product['product_id'], true),
                    'total' => $this->currency->format(
                        $order_product['total'] + ($this->config->get('config_tax') ? ($order_product['tax'] * $order_product['quantity']) : 0),
                        $result['currency_code'],
                        $result['currency_value']
                    ),
                );
            }

            $shipping_address = '';
            $payment_method = '';
            $shipping_method = '';

            if ($order_info) {
                $payment_method = $order_info['payment_method'];
                $shipping_method = $order_info['shipping_method'];

                if ($order_info['shipping_address_format']) {
                    $format = $order_info['shipping_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['shipping_firstname'],
                    'lastname'  => $order_info['shipping_lastname'],
                    'company'   => $order_info['shipping_company'],
                    'address_1' => $order_info['shipping_address_1'],
                    'address_2' => $order_info['shipping_address_2'],
                    'city'      => $order_info['shipping_city'],
                    'postcode'  => $order_info['shipping_postcode'],
                    'zone'      => $order_info['shipping_zone'],
                    'zone_code' => $order_info['shipping_zone_code'],
                    'country'   => $order_info['shipping_country']
                );

                $shipping_address = str_replace(
                    array("\r\n", "\r", "\n"),
                    '<br />',
                    preg_replace(
                        array("/\s\s+/", "/\r\r+/", "/\n\n+/"),
                        '<br />',
                        trim(str_replace($find, $replace, $format))
                    )
                );
            }

            $data['orders'][] = array(
                'order_id'   => $result['order_id'],
                'repeat'       => $this->url->link('account/order/repeat', 'order_id=' . $result['order_id'], 'SSL'),
                'name'       => $result['firstname'] . ' ' . $result['lastname'],
                'status'     => $result['status'],
                //'status_id'     => $result['order_status_id'],
                //'order_status_text_color'     => $result['order_status_text_color'],
                //'order_status_background_color'     => $result['order_status_background_color'],
                'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
                'products'   => ($product_total + $voucher_total),
                'thumbs' => $thumbs,
                'products_list' => $products_list,
                'payment_method' => $payment_method,
                'shipping_method' => $shipping_method,
                'shipping_address' => $shipping_address,
                'total'      => $this->currency->format($result['total'], $result['currency_code'], $result['currency_value']),
                'view'       => $this->url->link('account/order/info', 'order_id=' . $result['order_id'], true),
            );
        }

        $language_id = (int)$this->config->get('config_language_id');
        $data['language_id'] = $language_id;

        $data['no_orders'] = $this->config->get('theme_default_account_no_orders_status');

        if ($data['no_orders'] == 1) {
            if ($this->config->get('theme_default_account_no_orders')[$language_id]['image'] != '') {
                if (is_file(DIR_IMAGE . $this->config->get('theme_default_account_no_orders')[$language_id]['image'])) {
                // $data['account_no_orders'] = 'image/' . $this->config->get('theme_default_account_no_orders')[$language_id]['image'];
                $data['account_no_orders'] = $this->model_tool_image->resize($this->config->get('theme_default_account_no_orders')[$language_id]['image'], 1080, 265);
                } else {
                $data['account_no_orders'] = '';
                }
            }
        }

        $pagination = new Pagination();
        $pagination->total = $order_total;
        $pagination->page = $page;
        $pagination->limit = 10;
        $pagination->url = $this->url->link('account/order', 'page={page}', true);

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($order_total - 10)) ? $order_total : ((($page - 1) * 10) + 10), $order_total, ceil($order_total / 10));

        $order_history_total = $this->model_account_order->getTotalOrders();

        $results_history = $this->model_account_order->getOrders(($page - 1) * 10, 10);

        foreach ($results_history as $result) {
            $product_total = $this->model_account_order->getTotalOrderProductsByOrderId($result['order_id']);
            $voucher_total = $this->model_account_order->getTotalOrderVouchersByOrderId($result['order_id']);

            $data['history_orders'][] = array(
                'order_id'   => $result['order_id'],
                'name'       => $result['firstname'] . ' ' . $result['lastname'],
                'status'     => $result['status'],
                //'status_id'     => $result['order_status_id'],
                //'order_status_text_color'     => $result['order_status_text_color'],
                //'order_status_background_color'     => $result['order_status_background_color'],
                'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
                'products'   => ($product_total + $voucher_total),
                'total'      => $this->currency->format($result['total'], $result['currency_code'], $result['currency_value']),
                'view'       => $this->url->link('account/order/info', 'order_id=' . $result['order_id'], true),
            );
        }

        $pagination_history = new Pagination();
        $pagination_history->total = $order_history_total;
        $pagination_history->page = $page;
        $pagination_history->limit = 10;
        $pagination_history->url = $this->url->link('account/order', 'page={page}', true);

        $data['pagination'] = $pagination_history->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($order_history_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($order_history_total - 10)) ? $order_history_total : ((($page - 1) * 10) + 10), $order_history_total, ceil($order_history_total / 10));


        $data['continue'] = $this->url->link('account/account', '', true);

        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');

        $this->response->setOutput($this->load->view('account/order_list', $data));
    }

    public function info() {
        $this->load->language('account/order');

        if (isset($this->request->get['order_id'])) {
            $order_id = $this->request->get['order_id'];
        } else {
            $order_id = 0;
        }

        if (!$this->customer->isLogged()) {
            $this->session->data['redirect'] = $this->url->link('account/order/info', 'order_id=' . $order_id, true);

            $this->response->redirect($this->url->link('account/login', '', true));
        }

        $this->load->model('account/order');
        $this->load->model('tool/image');

        $order_info = $this->model_account_order->getOrder($order_id);

        if ($order_info) {
            $this->document->setTitle($this->language->get('text_order'));

            $url = '';

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $data['breadcrumbs'] = array();

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/home')
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_account'),
                'href' => $this->url->link('account/account', '', true)
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('account/order', $url, true)
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_order'),
                'href' => $this->url->link('account/order/info', 'order_id=' . $this->request->get['order_id'] . $url, true)
            );

            if (isset($this->session->data['error'])) {
                $data['error_warning'] = $this->session->data['error'];

                unset($this->session->data['error']);
            } else {
                $data['error_warning'] = '';
            }

            if (isset($this->session->data['success'])) {
                $data['success'] = $this->session->data['success'];

                unset($this->session->data['success']);
            } else {
                $data['success'] = '';
            }

            $data['order_status_name'] = $this->model_account_order->getOrderStatusName($order_info['order_status_id']);
            $data['date_added'] = $order_info['date_added'];
            $data['ttn'] = '';
            if ($order_info['invoice_no']) {
                $data['invoice_no'] = $order_info['invoice_prefix'] . $order_info['invoice_no'];
            } else {
                $data['invoice_no'] = '';
            }

            $data['order_id'] = $this->request->get['order_id'];
            $data['date_added'] = date($this->language->get('date_format_short'), strtotime($order_info['date_added']));

            if ($order_info['payment_address_format']) {
                $format = $order_info['payment_address_format'];
            } else {
                $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
            }

            $find = array(
                '{firstname}',
                '{lastname}',
                '{company}',
                '{address_1}',
                '{address_2}',
                '{city}',
                '{postcode}',
                '{zone}',
                '{zone_code}',
                '{country}'
            );

            $replace = array(
                'firstname' => $order_info['payment_firstname'],
                'lastname'  => $order_info['payment_lastname'],
                'company'   => $order_info['payment_company'],
                'address_1' => $order_info['payment_address_1'],
                'address_2' => $order_info['payment_address_2'],
                'city'      => $order_info['payment_city'],
                'postcode'  => $order_info['payment_postcode'],
                'zone'      => $order_info['payment_zone'],
                'zone_code' => $order_info['payment_zone_code'],
                'country'   => $order_info['payment_country']
            );

            $data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

            $data['payment_method'] = $order_info['payment_method'];

            if ($order_info['shipping_address_format']) {
                $format = $order_info['shipping_address_format'];
            } else {
                $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
            }

            $find = array(
                '{firstname}',
                '{lastname}',
                '{company}',
                '{address_1}',
                '{address_2}',
                '{city}',
                '{postcode}',
                '{zone}',
                '{zone_code}',
                '{country}'
            );

            $replace = array(
                'firstname' => $order_info['shipping_firstname'],
                'lastname'  => $order_info['shipping_lastname'],
                'company'   => $order_info['shipping_company'],
                'address_1' => $order_info['shipping_address_1'],
                'address_2' => $order_info['shipping_address_2'],
                'city'      => $order_info['shipping_city'],
                'postcode'  => $order_info['shipping_postcode'],
                'zone'      => $order_info['shipping_zone'],
                'zone_code' => $order_info['shipping_zone_code'],
                'country'   => $order_info['shipping_country']
            );

            $data['shipping_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

            $data['shipping_method'] = $order_info['shipping_method'];

            $this->load->model('catalog/product');
            $this->load->model('tool/upload');

            // Products
            $data['products'] = array();

            $products = $this->model_account_order->getOrderProducts($this->request->get['order_id']);

            foreach ($products as $product) {
                $option_data = array();

                $options = $this->model_account_order->getOrderOptions($this->request->get['order_id'], $product['order_product_id']);

                foreach ($options as $option) {
                    if ($option['type'] != 'file') {
                        $value = $option['value'];
                    } else {
                        $upload_info = $this->model_tool_upload->getUploadByCode($option['value']);

                        if ($upload_info) {
                            $value = $upload_info['name'];
                        } else {
                            $value = '';
                        }
                    }

                    $option_data[] = array(
                        'name'  => $option['name'],
                        'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
                    );
                }

                $product_info = $this->model_catalog_product->getProduct($product['product_id']);

                if ($product_info) {
                    $reorder = $this->url->link('account/order/reorder', 'order_id=' . $order_id . '&order_product_id=' . $product['order_product_id'], true);
                } else {
                    $reorder = '';
                }

                if (isset($product_info['image']) && is_file(DIR_IMAGE . $product_info['image'])) {
                    $image = $this->model_tool_image->resize($product_info['image'], 48, 48);
                } else {
                    $image = $this->model_tool_image->resize('no_image.jpg', 48, 48);
                }

                $data['products'][] = array(
                    'name'     => $product['name'],
                    'model'    => $product['model'],
                    'option'   => $option_data,
                    'image'    => $image,
                    'width' => 48,
                    'height' => 48,
                    'quantity' => $product['quantity'],
                    'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
                    'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']),
                    'reorder'  => $reorder,
                    'return'   => $this->url->link('account/return/add', 'order_id=' . $order_info['order_id'] . '&product_id=' . $product['product_id'], true),
                    'href'     => $this->url->link('product/product', 'product_id=' . $product['product_id'] . $url)
                );
            }

            // Voucher
            $data['vouchers'] = array();

            $vouchers = $this->model_account_order->getOrderVouchers($this->request->get['order_id']);

            foreach ($vouchers as $voucher) {
                $data['vouchers'][] = array(
                    'description' => $voucher['description'],
                    'amount'      => $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value'])
                );
            }

            // Totals
            $data['totals'] = array();

            $totals = $this->model_account_order->getOrderTotals($this->request->get['order_id']);

            foreach ($totals as $total) {
                $data['totals'][] = array(
                    'title' => $total['title'],
                    'code' => $total['code'],
                    'text'  => $this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']),
                );
            }



            $data['comment'] = nl2br($order_info['comment']);

            // History
            $data['histories'] = array();

            $results = $this->model_account_order->getOrderHistories($this->request->get['order_id']);

            foreach ($results as $result) {
                $data['histories'][] = array(
                    'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
                    'status'     => $result['status'],
                    'comment'    => $result['notify'] ? nl2br($result['comment']) : ''
                );
            }

            $data['continue'] = $this->url->link('account/order', '', true);

            $data['column_left'] = $this->load->controller('common/column_left');
            $data['column_right'] = $this->load->controller('common/column_right');
            $data['content_top'] = $this->load->controller('common/content_top');
            $data['content_bottom'] = $this->load->controller('common/content_bottom');
            $data['footer'] = $this->load->controller('common/footer');
            $data['header'] = $this->load->controller('common/header');
            $data['repeat'] = str_replace('&amp;','&',$this->url->link('account/order/repeat', 'order_id=' . $order_id, 'SSL'));
            $this->response->setOutput($this->load->view('account/order_info', $data));
        } else {
            return new Action('error/not_found');
        }
    }

    public function repeat() {
        $this->load->language('account/order');

        $json = array();

        if (isset($this->request->get['order_id'])) {
            $order_id = $this->request->get['order_id'];
        } else {
            $order_id = 0;
        }

        $this->load->model('account/order');

        $order_info = $this->model_account_order->getOrder($order_id);

        if ($order_info) {

            $order_product_info = $this->model_account_order->getOrderProducts($order_id);

            $this->load->model('catalog/product');

            foreach ($order_product_info as $order_product) {
                if ($order_product_info) {

                    $product_info = $this->model_catalog_product->getProduct($order_product['product_id']);

                    if ($product_info) {
                        $option_data = array();

                        $order_options = $this->model_account_order->getOrderOptions($order_id, $order_product['order_product_id']);

                        foreach ($order_options as $order_option) {
                            if ($order_option['type'] == 'select' || $order_option['type'] == 'radio' || $order_option['type'] == 'image') {
                                $option_data[$order_option['product_option_id']] = $order_option['product_option_value_id'];
                            } elseif ($order_option['type'] == 'checkbox') {
                                $option_data[$order_option['product_option_id']][] = $order_option['product_option_value_id'];
                            } elseif ($order_option['type'] == 'text' || $order_option['type'] == 'textarea' || $order_option['type'] == 'date' || $order_option['type'] == 'datetime' || $order_option['type'] == 'time') {
                                $option_data[$order_option['product_option_id']] = $order_option['value'];
                            } elseif ($order_option['type'] == 'file') {
                                $option_data[$order_option['product_option_id']] = $this->encryption->encrypt($order_option['value']);
                            }
                        }

                        $this->cart->add($order_product['product_id'], $order_product['quantity'], $option_data);

                        unset($this->session->data['shipping_method']);
                        unset($this->session->data['shipping_methods']);
                        unset($this->session->data['payment_method']);
                        unset($this->session->data['payment_methods']);
                    } else {
                        $this->session->data['error'] = sprintf($this->language->get('error_reorder'), $order_product_info['name']);
                    }
                }
            }


        }
        $json['total'] = $this->cart->countProducts();

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
        //$this->response->redirect($this->url->link('checkout/cart'));
    }

    public function reorder() {
        $this->load->language('account/order');

        if (isset($this->request->get['order_id'])) {
            $order_id = $this->request->get['order_id'];
        } else {
            $order_id = 0;
        }

        $this->load->model('account/order');

        $order_info = $this->model_account_order->getOrder($order_id);

        if ($order_info) {
            if (isset($this->request->get['order_product_id'])) {
                $order_product_id = $this->request->get['order_product_id'];
            } else {
                $order_product_id = 0;
            }

            $order_product_info = $this->model_account_order->getOrderProduct($order_id, $order_product_id);

            if ($order_product_info) {
                $this->load->model('catalog/product');

                $product_info = $this->model_catalog_product->getProduct($order_product_info['product_id']);

                if ($product_info) {
                    $option_data = array();

                    $order_options = $this->model_account_order->getOrderOptions($order_product_info['order_id'], $order_product_id);

                    foreach ($order_options as $order_option) {
                        if ($order_option['type'] == 'select' || $order_option['type'] == 'radio' || $order_option['type'] == 'image') {
                            $option_data[$order_option['product_option_id']] = $order_option['product_option_value_id'];
                        } elseif ($order_option['type'] == 'checkbox') {
                            $option_data[$order_option['product_option_id']][] = $order_option['product_option_value_id'];
                        } elseif ($order_option['type'] == 'text' || $order_option['type'] == 'textarea' || $order_option['type'] == 'date' || $order_option['type'] == 'datetime' || $order_option['type'] == 'time') {
                            $option_data[$order_option['product_option_id']] = $order_option['value'];
                        } elseif ($order_option['type'] == 'file') {
                            $option_data[$order_option['product_option_id']] = $this->encryption->encrypt($this->config->get('config_encryption'), $order_option['value']);
                        }
                    }

                    $this->cart->add($order_product_info['product_id'], $order_product_info['quantity'], $option_data);

                    $this->session->data['success'] = sprintf($this->language->get('text_success'), $this->url->link('product/product', 'product_id=' . $product_info['product_id']), $product_info['name'], $this->url->link('checkout/cart'));

                    unset($this->session->data['shipping_method']);
                    unset($this->session->data['shipping_methods']);
                    unset($this->session->data['payment_method']);
                    unset($this->session->data['payment_methods']);
                } else {
                    $this->session->data['error'] = sprintf($this->language->get('error_reorder'), $order_product_info['name']);
                }
            }
        }

        $this->response->redirect($this->url->link('account/order/info', 'order_id=' . $order_id));
    }

    function getCheckoutUrl($order_info, string $ccy) {
        $this->load->model('extension/payment/mono');
        $payment_type = 'debit';
        $hold_status = $this->config->get('payment_mono_use_holds');
        if ($hold_status == 1) {
            $payment_type = 'hold';
        }
        $create_invoice_response = $this->createInvoice($order_info, $payment_type, $ccy);
        $this->model_extension_payment_mono->InvoiceInsert($create_invoice_response['invoiceId'], $order_info['order_id'], $payment_type, (int)($order_info['total'] * 100 + 0.5), 0, 0, 'created', self::CURRENCY_CODE[$ccy], 0);
        return $create_invoice_response['pageUrl'];
    }

    function createInvoice($order_info, string $payment_type, string $ccy) {
        if (VERSION < '3.0.0.0') {
            $prefix = '';
        } else {
            $prefix = 'payment_';
        }

        $destination = $this->config->get($prefix . 'mono_destination');

        $total = (int)($order_info['total'] * 100 + 0.5);
        $basket_order = $this->getEncodedProducts($order_info['order_id'], $total);

        $customer_emails = [];
        if (key_exists('email', $order_info) && $order_info['email']) {
            $customer_emails = [$order_info['email']];
        }

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.monobank.ua/api/merchant/invoice/create',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode([
                'amount' => $total,
                'ccy' => self::CURRENCY_CODE[$ccy],
                'merchantPaymInfo' => [
                    'reference' => (string)$order_info['order_id'],
                    'destination' => $destination,
                    'basketOrder' => $basket_order,
                    'customerEmails' => $customer_emails,
                ],
                'redirectUrl' => (string)$this->url->link('extension/payment/mono/response', '', true),
                'paymentType' => $payment_type,
                'webHookUrl' => str_replace('&amp;', '&', $this->removeMiddlePath($this->url->link('extension/payment/mono/callback'))),]),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'X-Token: ' . $this->config->get('payment_mono_merchant'),
                'X-Cms: Opencart',
                'X-Cms-Version: ' . VERSION,
            ),
        ));

        $response = curl_exec($curl);

        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if (!$response) {
            throw new ErrorException('No response');
        }

        if ($httpcode != 200) {
            throw new ErrorException('Got an error: ' . $httpcode);
        }
        return json_decode($response, true);
    }

    public function getEncodedProducts(int $orderId, int $order_total) {
        $this->load->model('checkout/order');

        $order_products = $this->model_extension_payment_mono->getOrderProducts($orderId);
        $product_ids = [];
        foreach ($order_products as $order_product) {
            $product_ids[] = $order_product['product_id'];
        }
        $products = $this->model_extension_payment_mono->getProducts($product_ids);
        $products_map = [];
        foreach ($products as $product) {
            $products_map[$product['product_id']] = $product;
        }

        $fiscalization_code_field = $this->config->get('payment_mono_fiscalization_code_field');
        if (empty($fiscalization_code_field)) {
            $fiscalization_code_field = 'sku';
        }
        $total_from_basket = 0;
        $basket = [];
        foreach ($order_products as $order_product) {
            $sum = (int)($order_product['price'] * 100 + 0.5);
            $qty = (float)$order_product['quantity'];
            $p = $products_map[$order_product['product_id']];
            $qty_rest = $qty;

//            splitting multiple qty items so that discount coupons will be correctly applied to prices
            while ($qty_rest >= 1) {
                $basket[] = [
                    'name' => $order_product['name'],
                    'sum' => $sum,
                    'qty' => 1,
                    'code' => $p[$fiscalization_code_field],
                    'icon' => HTTPS_SERVER . "/image/" . $p['image'],
                ];
                $qty_rest -= 1;
            }
            if (!$this->floats_equal($qty_rest, 0)) {
                $basket[] = [
                    'name' => $order_product['name'],
                    'sum' => $sum,
                    'qty' => $qty_rest,
                    'code' => $p[$fiscalization_code_field],
                    'icon' => HTTPS_SERVER . "/image/" . $p['image'],
                ];
            }
            $total_from_basket += $qty * $sum;
        }

        $discount = 0;
        if ($total_from_basket != $order_total) {
            $totals = $this->model_extension_payment_mono->getTotals($orderId);
            foreach ($totals as $total) {
                $code = $total['code'];
                if ($code == 'total' || $code == 'sub_total') {
                    continue;
                }
                if ($total['value'] < 0) {
                    $discount += (int)($total['value'] * 100 - 0.5);
                    continue;
                }
                $basket[] = [
                    'name' => $total['title'],
                    'sum' => (int)($total['value'] * 100 + 0.5),
                    'qty' => 1,
                    'code' => $code,
                ];
            }
        }
        $discount = abs($discount);
        if ($discount > 0) {
            foreach ($basket as &$item) {
                if ($discount >= $item['sum'] && $item['sum'] > 1) {
                    $discount -= $item['sum'] - 1;
                    $item['sum'] = 1;
                } else {
                    $item['sum'] -= $discount;
                    break;
                }
            }
            unset($item);
        }
        return $basket;
    }

    function removeMiddlePath($url) {
        $parsed_url = parse_url($url);
        // Reconstruct the URL with the modified path
        $port = (isset($parsed_url['port']) && strlen($parsed_url['port']) > 0) ? ':' . $parsed_url['port'] : '';
        $new_url = $parsed_url['scheme'] . '://' . $parsed_url['host'] . $port . '/index.php';

        // Add the query string and fragment if they exist
        if (isset($parsed_url['query'])) {
            $new_url .= '?' . $parsed_url['query'];
        }

        if (isset($parsed_url['fragment'])) {
            $new_url .= '#' . $parsed_url['fragment'];
        }

        return $new_url;
    }

    private function floats_equal($fist_value, $second_value) {
        $tolerance = 0.001;
        return (abs($fist_value) - abs($second_value)) < $tolerance;
    }
}
