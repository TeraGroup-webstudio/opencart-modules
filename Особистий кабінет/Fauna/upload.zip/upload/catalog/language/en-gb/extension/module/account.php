<?php

// Heading
$_['heading_title']    = 'Account';

// Text
$_['text_register']    = 'Register';
$_['text_login']       = 'Login';
$_['text_logout']      = 'Logout';
$_['text_forgotten']   = 'Forgotten Password';
$_['text_account']     = 'My Account';
$_['text_edit']        = 'Edit Account';
$_['text_password']    = 'Password';
$_['text_address']     = 'Address Book';
$_['text_wishlist']    = 'Wish List';
$_['text_order']       = 'Order History';
$_['text_download']    = 'Downloads';
$_['text_reward']      = 'Reward Points';
$_['text_return']      = 'Returns';
$_['text_transaction'] = 'Transactions';
$_['text_newsletter']  = 'Newsletter';
$_['text_recurring']   = 'Recurring payments';

$_['text_personal_discount'] = 'Personal Discount';
$_['text_bonus_menu']        = 'Bonuses';
$_['text_balance']           = 'Balance';
$_['text_order_menu']        = 'Orders';
$_['text_wishlist_menu']     = 'Wishlist';
$_['text_settings_menu']     = 'Settings';