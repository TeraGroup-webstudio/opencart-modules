<?php

// Heading
$_['heading_title'] = 'Личный кабинет';

// Text
$_['text_register'] = 'Регистрация';
$_['text_login'] = 'Вход';
$_['text_logout'] = 'Выход';
$_['text_forgotten'] = 'Забыли пароль?';
$_['text_account'] = 'Личный кабинет';
$_['text_edit'] = 'Личные данные';
$_['text_password'] = 'Изменение пароля';
$_['text_address'] = 'Адреса доставки';
$_['text_wishlist'] = 'Закладки';
$_['text_order'] = 'Последние заказы';
$_['text_download'] = 'Загрузочные файлы';
$_['text_reward'] = 'Бонусные баллы';
$_['text_return'] = 'Возврат товара';
$_['text_transaction'] = 'История платежей';
$_['text_newsletter'] = 'Подписка к новостям';
$_['text_recurring'] = 'Регулярные платежи';

$_['text_personal_discount'] = 'Персональная скидка';
$_['text_bonus_menu']    = 'Бонусы';
$_['text_balance']       = 'Баланс';
$_['text_order_menu']    = 'Заказы';
$_['text_wishlist_menu'] = 'Избранное';
$_['text_settings_menu'] = 'Настройки';