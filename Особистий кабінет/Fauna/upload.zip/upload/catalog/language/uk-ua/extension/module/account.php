<?php

// Heading
$_['heading_title']          = 'Особистий кабінет';

// Text
$_['text_register']          = 'Реєстрація';
$_['text_login']             = 'Вхід';
$_['text_logout']            = 'Вихід';
$_['text_forgotten']         = 'Забули пароль?';
$_['text_account']           = 'Особистий кабінет';
$_['text_edit']              = 'Особисті дані';
$_['text_password']          = 'Зміна паролю';
$_['text_address']           = 'Адреси доставки';
$_['text_wishlist']          = 'Закладки';
$_['text_order']             = 'Останні замовлення';
$_['text_download']          = 'Файли для завантаження';
$_['text_reward']            = 'Бонусні бали';
$_['text_return']            = 'Повернення товару';
$_['text_transaction']       = 'Історія платежів';
$_['text_newsletter']        = 'Підписка на новини';
$_['text_recurring']         = 'Регулярні платежі';

$_['text_personal_discount'] = 'Персональна знижка';
$_['text_bonus_menu']        = 'Бонуси';
$_['text_balance']           = 'Баланс';
$_['text_order_menu']        = 'Замовлення';
$_['text_wishlist_menu']     = 'Обране';
$_['text_settings_menu']     = 'Налаштування';