<?php
class ControllerExtensionModuleAccount extends Controller {
	public function index() {
		// $this->document->addStyle('catalog/view/theme/default/stylesheet/breadcrumb.css', 'stylesheet');
		$this->document->addStyle('catalog/view/theme/default/stylesheet/pagination.css', 'stylesheet');

		$this->load->language('extension/module/account');

		$data['logged'] = $this->customer->isLogged();

		// Links
		$data['register'] = $this->url->link('account/register', '', true);
		$data['login'] = $this->url->link('account/login', '', true);
		$data['logout'] = $this->url->link('account/logout', '', true);
		$data['forgotten'] = $this->url->link('account/forgotten', '', true);
		$data['account'] = $this->url->link('account/account', '', true);
		$data['edit'] = $this->url->link('account/edit', '', true);
		$data['password'] = $this->url->link('account/password', '', true);
		$data['address'] = $this->url->link('account/address', '', true);
		$data['wishlist'] = $this->url->link('account/wishlist');
		$data['order'] = $this->url->link('account/order', '', true);
		$data['download'] = $this->url->link('account/download', '', true);
		$data['reward'] = $this->url->link('account/reward', '', true);
		$data['return'] = $this->url->link('account/return', '', true);
		$data['transaction'] = $this->url->link('account/transaction', '', true);
		$data['newsletter'] = $this->url->link('account/newsletter', '', true);
		$data['recurring'] = $this->url->link('account/recurring', '', true);

		// ===== Bonus points (Reward) =====
		$data['reward_points'] = 0;

		if ($this->customer->isLogged()) {
			// у OC3 це поле існує в customer
			$data['reward_points'] = (int)$this->customer->getRewardPoints();
		}

		$data['wishlist_count'] = 0;

		if ($this->customer->isLogged()) {
			$this->load->model('account/wishlist');
			$data['wishlist_count'] = (int)$this->model_account_wishlist->getTotalWishlist();
		} else {
			// для гостей wishlist зберігається в session
			$data['wishlist_count'] = isset($this->session->data['wishlist']) ? count($this->session->data['wishlist']) : 0;
		}


		if ($this->customer->isLogged()) {
			return $this->load->view('extension/module/account', $data);
		}
	}
}
