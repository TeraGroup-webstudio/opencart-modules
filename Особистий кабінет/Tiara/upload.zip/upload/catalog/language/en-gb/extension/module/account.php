<?php

// Heading
$_['heading_title']         = 'My Account';

// Text
$_['text_account']          = 'Personal account';
$_['text_my_account']       = 'Account';
$_['text_my_orders']        = 'Orders';
$_['text_my_affiliate']     = 'Affiliate section';
$_['text_my_newsletter']    = 'Subscription';
$_['text_edit']             = 'Contact information';
$_['text_password']         = 'Change password';
$_['text_address']          = 'Change of addresses';
$_['text_credit_card']      = 'Manage credit cards';
$_['text_account_wishlist'] = 'Manage bookmarks';
$_['text_order']            = 'Order History';
$_['text_download']         = 'Files to download';
$_['text_reward']           = 'Bonus Points';
$_['text_return']           = 'Request product return';
$_['text_transaction']      = 'History of payments';
$_['text_newsletter']       = 'Subscribe or unsubscribe';
$_['text_recurring']        = 'Recurring payments';
$_['text_transactions']     = 'Transactions';
$_['text_affiliate_add']    = 'Affiliate account registration';
$_['text_affiliate_edit']   = 'Manage affiliate information';
$_['text_tracking']         = 'Partner tracking code';
$_['text_wishlist']         = 'Bookmarks';
$_['text_upload_success']   = 'Photo uploaded successfully';
$_['text_upload_error']     = 'Failed to upload photo';
$_['text_no_file']          = 'No files uploaded';
$_['text_delete_success']   = 'Photo deleted successfully';
$_['text_delete_error']     = 'Failed to delete photo';
$_['photo__title']          = 'Profile Picture';
$_['text_note_avatar']      = 'Add your avatar';