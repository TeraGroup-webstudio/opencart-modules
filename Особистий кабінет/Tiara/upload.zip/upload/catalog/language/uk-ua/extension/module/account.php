<?php
// *	@copyright		Pavel Kravchenko; https://opencartforum.com/profile/711752-paulkravchenko/

// Heading
$_['heading_title']      = 'Особистий кабінет';

// Text
$_['text_account']       = 'Особистий кабінет';
$_['text_my_account']    = 'Обліковий запис';
$_['text_my_orders']     = 'Замовлення';
$_['text_my_affiliate']  = 'Партнерській розділ';
$_['text_my_newsletter'] = 'Підписка';
$_['text_edit']          = 'Контактна інформація';
$_['text_password']      = 'Зміна пароля';
$_['text_address']       = 'Зміна адрес';
$_['text_credit_card']   = 'Керування банківськими картками';
$_['text_account_wishlist'] = 'Керування закладками';
$_['text_order']         = 'Історія замовлень';
$_['text_download']      = 'Файли для завантаження';
$_['text_reward']        = 'Бонусні бали';
$_['text_return']        = 'Запити на повернення товару';
$_['text_transaction']   = 'Історія платежів';
$_['text_newsletter']    = 'Підписатись або відмовитись від підписки';
$_['text_recurring']     = 'Регулярні платежі';
$_['text_transactions']  = 'Операції';
$_['text_affiliate_add'] = 'Реєстрація партнерського облікового запису';
$_['text_affiliate_edit'] = 'Керування партнерською інформацією';
$_['text_tracking']      = 'Код відстеження партнерів';
$_['text_wishlist']      = 'Закладки';
$_['text_upload_success'] = 'Фото завантажено успішно';
$_['text_upload_error'] = 'Не вдалося завантажити фото';
$_['text_no_file'] = 'Немає завантажених файлів';
$_['text_delete_success'] = 'Фото успішно видалено';
$_['text_delete_error'] = 'Не вдалося видалити фото';
$_['photo__title'] = 'Зображення профілю';
$_['text_note_avatar'] = 'Додайте своє зображення';

